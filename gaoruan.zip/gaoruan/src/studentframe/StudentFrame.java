package studentframe;

import java.awt.*;

import javax.swing.*;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jdbc.DbManager;
import studentframe.QA.askQuestion;
import studentframe.QA.getQuestion;
import studentframe.exam.ExamSearch;
import studentframe.teacherAssistance.answerQuestion;
import studentframe.work.commitWork;
import studentframe.work.getWork;
import util.DisplayFonts;
import util.CenterFrame;

public class StudentFrame extends JFrame {
	private String studentID;

	public StudentFrame(String studentID) {
		try {
			jbInit();
			this.studentID = studentID;
		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	private void jbInit() throws Exception {
		getContentPane().setLayout(null);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setFont(new java.awt.Font("����", Font.BOLD, 14));
		this.setJMenuBar(jMenuBar1);
		this.setTitle("�������ϵͳ");
		menu1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menu1.setText("ϵͳ");
		menu2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menu2.setText("�ɼ���ѯ");
		menuItem1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuItem1.setText("�˳�");
		menuItem1.addActionListener(new StudentFrame_menuItem1_actionAdapter(
				this));
		menuItem2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuItem2.setText("��ѯ");
		menuItem2.addActionListener(new StudentFrame_menuItem2_actionAdapter(
				this));

		// add ����
		menuQA.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuQA.setText("����");

		menuItemAsk.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuItemAsk.setText("�ύ����");
		menuItemAsk
				.addActionListener(new StuedntFrame_menuItemAsk_actionAdapter(
						this));

		menuItemGetQuestion.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuItemGetQuestion.setText("�鿴����");
		menuItemGetQuestion
				.addActionListener(new StuedntFrame_menuItemGetQuestion_actionAdapter(
						this));

		menuQA.add(menuItemAsk);
		menuQA.add(menuItemGetQuestion);

		// add �ύ��ҵ
		menuCommitWork.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuCommitWork.setText("�ύ��ҵ");

		menuItemCommitWork.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuItemCommitWork.setText("�ύ");
		menuItemCommitWork
				.addActionListener(new StuedntFrame_menuItemCommitWork_actionAdapter(
						this));

		menuItemGetWork.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuItemGetWork.setText("�鿴");
		menuItemGetWork
				.addActionListener(new StuedntFrame_menuItemGetWork_actionAdapter(
						this));

		menuCommitWork.add(menuItemCommitWork);
		menuCommitWork.add(menuItemGetWork);
		
		//add ����ҳ��
		menuTA.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuTA.setText("����");
		
		menuItemAnswer.setFont(new java.awt.Font("������", Font.PLAIN, 13));
		menuItemAnswer.setText("�ش�����");
		menuItemAnswer.addActionListener(new StudentFrame_menuItemAnswer_actionAdapter(this));
		
		menuTA.add(menuItemAnswer);
		
		jMenuBar1.add(menu1);
		jMenuBar1.add(menu2);
		jMenuBar1.add(menuQA);
		jMenuBar1.add(menuCommitWork);
		jMenuBar1.add(menuTA);
		
		menu1.add(menuItem1);
		menu2.add(menuItem2);

		jLabel1.setIcon(img1);
		jLabel1.setBounds(new Rectangle(0, 0, 800, 545));
		this.getContentPane().add(jLabel1);

		this.setUndecorated(true);// ����ʾWindows������
		this.getRootPane().setWindowDecorationStyle(JRootPane.PLAIN_DIALOG); // ��ʾjava
																				// ������
		this.setSize(800, 600);
		CenterFrame.center(this); // �������
		this.setVisible(true);
		this.setResizable(false);

	}

	JMenuBar jMenuBar1 = new JMenuBar();
	JMenu menu1 = new JMenu();
	JMenu menu2 = new JMenu();
	JMenuItem menuItem1 = new JMenuItem();
	JMenuItem menuItem2 = new JMenuItem();
	JLabel jLabel1 = new JLabel();
	ImageIcon img1 = new ImageIcon(this.getClass().getResource(
			"/img/studentFrame.jpg"));

	// QA��ť
	JMenu menuQA = new JMenu();
	JMenuItem menuItemAsk = new JMenuItem();
	JMenuItem menuItemGetQuestion = new JMenuItem();

	// �ύ��ҵ��ť
	JMenu menuCommitWork = new JMenu();
	JMenuItem menuItemCommitWork = new JMenuItem();
	JMenuItem menuItemGetWork = new JMenuItem();

	//����
	JMenu menuTA= new JMenu();
	JMenuItem menuItemAnswer = new JMenuItem();
	
	
	public void menuItem1_actionPerformed(ActionEvent e) {
		System.exit(0);
	}

	public void menuItem2_actionPerformed(ActionEvent e) {
		DisplayFonts.initGlobalFontSetting("������", 13); // ������ڴ������֮ǰ �������������֮ǰ
		ExamSearch c = new ExamSearch();
		c.setSize(400, 430);
		c.setLocation(280, 130);
		c.setVisible(true);
		c.setResizable(false);
	}

	public void menuItemAsk() {
		DisplayFonts.initGlobalFontSetting("������", 13); // ������ڴ������֮ǰ �������������֮ǰ
		askQuestion c = new askQuestion(this.studentID);
		c.setSize(400, 430);
		c.setLocation(280, 130);
		c.setVisible(true);
		c.setResizable(false);
	}

	public void menuItemGetQuestion() {
		DisplayFonts.initGlobalFontSetting("������", 13); // ������ڴ������֮ǰ �������������֮ǰ
		getQuestion c = new getQuestion();
		c.setSize(400, 430);
		c.setLocation(280, 130);
		c.setVisible(true);
		c.setResizable(false);
	}

	public void menuItemCommitWork() {
		DisplayFonts.initGlobalFontSetting("������", 13); // ������ڴ������֮ǰ �������������֮ǰ
		commitWork c = new commitWork(studentID);
		c.setSize(400, 430);
		c.setLocation(280, 130);
		c.setVisible(true);
		c.setResizable(false);
	}

	public void menuItemGetWork() {
		DisplayFonts.initGlobalFontSetting("������", 13); // ������ڴ������֮ǰ �������������֮ǰ
		getWork c = new getWork(studentID);
		c.setSize(400, 430);
		c.setLocation(280, 130);
		c.setVisible(true);
		c.setResizable(false);

	}

	public void menuItemAnswer() {
		// TODO Auto-generated method stub
		DisplayFonts.initGlobalFontSetting("������", 13); // ������ڴ������֮ǰ �������������֮ǰ
		answerQuestion c = new answerQuestion();
		c.setSize(400, 430);
		c.setLocation(280, 130);
		c.setVisible(true);
		c.setResizable(false);
	}

}

class StudentFrame_menuItem2_actionAdapter implements ActionListener {
	private StudentFrame adaptee;
	private ActionEvent e;

	StudentFrame_menuItem2_actionAdapter(StudentFrame adaptee) {
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent actionEvent) {
		adaptee.menuItem2_actionPerformed(e);
	}
}

class StudentFrame_menuItem1_actionAdapter implements ActionListener {
	private StudentFrame adaptee;

	StudentFrame_menuItem1_actionAdapter(StudentFrame adaptee) {
		this.adaptee = adaptee;
	}

	public void actionPerformed(ActionEvent e) {
		adaptee.menuItem1_actionPerformed(e);
	}
}

class StuedntFrame_menuItemAsk_actionAdapter implements ActionListener {
	private StudentFrame adaptee;

	public StuedntFrame_menuItemAsk_actionAdapter(StudentFrame adaptee) {
		this.adaptee = adaptee;
		// TODO Auto-generated constructor stub
	}

	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		adaptee.menuItemAsk();

	}

}

class StuedntFrame_menuItemGetQuestion_actionAdapter implements ActionListener {
	private StudentFrame adaptee;

	public StuedntFrame_menuItemGetQuestion_actionAdapter(StudentFrame adaptee) {
		// TODO Auto-generated constructor stub
		this.adaptee = adaptee;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		adaptee.menuItemGetQuestion();
	}

}

class StuedntFrame_menuItemCommitWork_actionAdapter implements ActionListener {
	private StudentFrame adaptee;

	public StuedntFrame_menuItemCommitWork_actionAdapter(StudentFrame adaptee) {
		// TODO Auto-generated constructor stub
		this.adaptee = adaptee;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		adaptee.menuItemCommitWork();
	}

}

class StuedntFrame_menuItemGetWork_actionAdapter implements ActionListener {
	private StudentFrame adaptee;

	public StuedntFrame_menuItemGetWork_actionAdapter(StudentFrame adaptee) {
		// TODO Auto-generated constructor stub
		this.adaptee = adaptee;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		adaptee.menuItemGetWork();

	}
}

class StudentFrame_menuItemAnswer_actionAdapter implements ActionListener {
	private StudentFrame adaptee;

	public StudentFrame_menuItemAnswer_actionAdapter(StudentFrame adaptee) {
		// TODO Auto-generated constructor stub
		this.adaptee = adaptee;
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		adaptee.menuItemAnswer();

	}
}

