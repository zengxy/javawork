package studentframe.QA;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import jdbc.DbManager;

public class askQuestion extends JFrame {

	JPanel mainJPanel = new JPanel();

	JLabel questionLabel = new JLabel("��������");
	JTextArea questionArea = new JTextArea();

	JLabel courseLabel = new JLabel("�γ̱��");
	JComboBox<String> courseIDBox = new JComboBox<String>();

	JLabel blanklaJLabel = new JLabel(" ");
	JButton commitButton = new JButton("�ύ");

	private String studentID;

	public askQuestion(String studentID) {
		// TODO Auto-generated constructor stub
		this.setTitle("�ύ����");
		this.studentID = studentID;

		mainJPanel.setLayout(new GridLayout(3, 2));

		questionArea.setTabSize(4);
		// questionArea.setFont(new Font("�꿬��", Font.BOLD, 13));
		questionArea.setLineWrap(true);// �����Զ����й���
		questionArea.setWrapStyleWord(true);// ������в����ֹ���
		questionArea.setBackground(Color.white);

		List<String> courses = getCourses();
		for (String course : courses)
			courseIDBox.addItem(course);

		mainJPanel.add(questionLabel);
		mainJPanel.add(questionArea);

		mainJPanel.add(courseLabel);
		mainJPanel.add(courseIDBox);

		mainJPanel.add(blanklaJLabel);

		commitButton
				.addMouseListener(new ask_commit_Button_actionAdapter(this));

		mainJPanel.add(commitButton);

		this.add(mainJPanel);

	}

	private List<String> getCourses() {
		List<String> courses = new ArrayList<String>();
		DbManager db = new DbManager();
		String sqlQuery = "select courseID from course";
		ResultSet rs = db.query(sqlQuery);

		rs = db.query(sqlQuery);

		try {
			while (rs.next())
				courses.add(rs.getString(1));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return courses;
	}

	public void commitButtonClickAction() {
		String courseID = courseIDBox.getSelectedItem().toString();
		String question = questionArea.getText();

		String sqlGetNum = "select max(problemnum) from problem";
		DbManager db = new DbManager();
		ResultSet rs = db.query(sqlGetNum);
		try {
			int problemNum = 0;
			if (rs.next())
				problemNum = Integer.parseInt(rs.getString(1)) + 1;

			String sqlQuery = "insert into problem(problemnum,problemname,courseID,TstuID) values('"
					+ Integer.toString(problemNum)
					+ "','"
					+ question
					+ "','"
					+ courseID + "','" + this.studentID + "')";
			db.query(sqlQuery);
			
			JOptionPane.showMessageDialog(null,"���ʳɹ���","��Ϣ��ʾ",JOptionPane.INFORMATION_MESSAGE);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null,"����ʧ�ܣ�","��Ϣ��ʾ",JOptionPane.ERROR_MESSAGE);

		}

	}

}

class ask_commit_Button_actionAdapter extends MouseAdapter {
	private askQuestion adaptee;

	ask_commit_Button_actionAdapter(askQuestion adaptee) {
		this.adaptee = adaptee;
	}

	public void mouseClicked(MouseEvent e) {
		if (e.getButton() == MouseEvent.BUTTON1)
			adaptee.commitButtonClickAction();
	}
}
