package studentframe.QA;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import jdbc.DbManager;

public class getQuestion extends JFrame {

	JScrollPane mainJScrollPane = new JScrollPane();
	JTable questionTable = new JTable();

	public getQuestion() {
		// TODO Auto-generated constructor stub

		try {
			jbInit();
			questionTable.setModel(this
					.refreshModel("select problemname,answer from problem"));
			questionTable.setEnabled(false);
            questionTable.getTableHeader().setReorderingAllowed(false);  //���ñ�ͷ�����ƶ�

		} catch (Exception exception) {
			exception.printStackTrace();
		}
	}

	private void jbInit() throws Exception {
		mainJScrollPane.getViewport().add(questionTable);
		this.add(mainJScrollPane);
		this.setTitle("Q&A");
	}

	private DefaultTableModel refreshModel(String sql) {
		Vector data = new Vector();
		Vector head = new Vector();
		head.add("����");
		head.add("��");
		DefaultTableModel model = new DefaultTableModel(); // ����һ��ģ��

		DbManager db = new DbManager();
		ResultSet rs = db.query(sql);

		try {
			while (rs.next()) {
				Vector v = new Vector();
				v.add(rs.getString(1));
				v.add(rs.getString(2));
				data.add(v);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		model.setDataVector(data, head);
		return model;
	}
}