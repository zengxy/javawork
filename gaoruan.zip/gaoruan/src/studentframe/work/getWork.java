package studentframe.work;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import jdbc.DbManager;

public class getWork extends JFrame {
	private String studentID;
	JScrollPane mainJScrollPane = new JScrollPane();
	JTable workTable = new JTable();
	
	public getWork(String studentID) {
		// TODO Auto-generated constructor stub
		
		try {
			this.studentID=studentID;
			jbInit();
			workTable.setModel(this
					.refreshModel("select courseID,stuID,workname,download from homework where stuID='"+this.studentID+"'"));
			workTable.setEnabled(false);
            workTable.getTableHeader().setReorderingAllowed(false);  //���ñ�ͷ�����ƶ�

		} catch (Exception exception) {
			exception.printStackTrace();
		}
		
	}
	
	private void jbInit() throws Exception {
		mainJScrollPane.getViewport().add(workTable);
		this.add(mainJScrollPane);
		this.setTitle("Q&A");
	}
	
	private DefaultTableModel refreshModel(String sql) {
		Vector data = new Vector();
		Vector head = new Vector();
		
		head.add("�γ̺�");
		head.add("ѧ��");
		head.add("����");
		head.add("��");
		DefaultTableModel model = new DefaultTableModel(); // ����һ��ģ��

		DbManager db = new DbManager();
		ResultSet rs = db.query(sql);

		try {
			while (rs.next()) {
				Vector v = new Vector();
				v.add(rs.getString(1));
				v.add(rs.getString(2));
				v.add(rs.getString(3));
				v.add(rs.getString(4));
				data.add(v);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		model.setDataVector(data, head);
		return model;
	}
	




}
