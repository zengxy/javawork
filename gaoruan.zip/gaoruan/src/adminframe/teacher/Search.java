package adminframe.teacher;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import java.sql.*;
import jdbc.DbManager;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import teacherframe.classess.SearchClass;

public class Search extends JFrame {
    public Search() {
        try {
            jbInit();
            refresh("select * from teacher");
            table.setSelectionMode(0);    //����ֻ��ѡ��һ����¼
            table.getTableHeader().setReorderingAllowed(false);  //���ñ�ͷ�����ƶ�
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    DbManager db=new DbManager();
    public void refresh(String sql)
    {
      ResultSet rs=db.query(sql);
      Vector data=new Vector();
      Vector head=new Vector();
      head.add("���");
      head.add("����");
      head.add("�绰");
      head.add("��ע");
    try {
        while (rs.next())
        {
          Vector v=new Vector();
          v.add(rs.getString(1));
          v.add(rs.getString(2));
          v.add(rs.getString(3));
          v.add(rs.getString(4));
          data.add(v);
        }
      } catch (SQLException ex)
       {
         System.out.println(ex.getMessage());
       }
    model.setDataVector(data,head);
    table.setModel(model);

    }
  DefaultTableModel model=new DefaultTableModel();    //����һ��Ĭ�ϱ���ģ��



    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        this.setTitle("��ʦ��Ϣ����");
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("�� ʦ �� Ϣ �� ��");
        lab.setBounds(new Rectangle(114, 29, 196, 39));
        jScrollPane1.setBounds(new Rectangle(31, 71, 374, 218));
        but1.setBounds(new Rectangle(40, 308, 83, 32));
        but1.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        but1.setText("����");
        but1.addActionListener(new Search_but1_actionAdapter(this));
        but2.setBounds(new Rectangle(140, 308, 73, 32));
        but2.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        but2.setText("�޸�");
        but2.addActionListener(new Search_but2_actionAdapter(this));
        but3.setBounds(new Rectangle(234, 308, 80, 32));
        but3.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        but3.setText("ɾ��");
        but3.addActionListener(new Search_but3_actionAdapter(this));
        but4.setBounds(new Rectangle(331, 308, 67, 32));
        but4.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        but4.setText("�˳�");
        but4.addActionListener(new Search_but4_actionAdapter(this));
        this.getContentPane().add(jScrollPane1);
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        this.getContentPane().add(but3);
        this.getContentPane().add(but4);
        this.getContentPane().add(lab);
        jScrollPane1.getViewport().add(table);
    }

    JLabel lab = new JLabel();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTable table = new JTable();
    JButton but1 = new JButton();
    JButton but2 = new JButton();
    JButton but3 = new JButton();
    JButton but4 = new JButton();

      public void but1_actionPerformed(ActionEvent e)
      {
        InsertMessage m=new InsertMessage(this);     //������һ������,ͬʱ���Լ�����ȥ this���ǵ�ǰ�Ĵ���
        m.setUndecorated(true);//����ʾWindows������
        m.getRootPane().setWindowDecorationStyle(JRootPane.FRAME   );  //��ʾjava ������
        m.setSize(400,440);
        m.setLocation(320,140);
        m.setVisible(true);
        m.setResizable(false);

    }

    public void but3_actionPerformed(ActionEvent e) {
      int row=table.getSelectedRow();
      if(row>=0)
      {
        String id=(String)model.getValueAt(row,0);
        int n=db.exec("delete from teacher where teacherID='"+id+"'");
        if(n==1)
        {
            refresh("select * from teacher");
          JOptionPane.showMessageDialog(this,"ɾ���ɹ�");

        }else
        {
          int j=JOptionPane.showConfirmDialog(this,"�ð�����Ŀǰ�ڴ���\n�Ƿ�ǰ���༶����ɾ��","ɾ����¼",JOptionPane.YES_NO_OPTION );
          if(!(j==1))
          {
              SearchClass searchclass = new SearchClass();
              searchclass.setUndecorated(true);//����ʾWindows������
              searchclass.getRootPane().setWindowDecorationStyle(JRootPane.FRAME);  //��ʾjava ������
              searchclass.setSize(700,500);
              searchclass.setLocation(150,110);
              searchclass.setVisible(true);
              searchclass.setResizable(false);

          }
       }
      }else
      {
          JOptionPane.showMessageDialog(this,"��ѡ��һ����¼");
      }
    }

    public void but4_actionPerformed(ActionEvent e) {
       this.setVisible(false);
    }

    public void but2_actionPerformed(ActionEvent e)
    {
        int row=table.getSelectedRow();    //��ȡ�кţ�������ȥ����
        if(row>=0)
        {
         String id=(String)model.getValueAt(row,0);
         String name=(String)model.getValueAt(row,1);
         String tel=(String)model.getValueAt(row,2);
         String memo=(String)model.getValueAt(row,3);
         UpdateMessage u=new UpdateMessage(this);
         u.setUndecorated(true);//����ʾWindows������
         u.getRootPane().setWindowDecorationStyle(JRootPane.FRAME   );  //��ʾjava ������
         u.setSize(400,440);
         u.setLocation(320,140);
         u.setVisible(true);
         u.setResizable(false);
         u.setData(id,name,tel,memo);   //����setData()���� ��id,name,tel,memo����ȥ
       }else
       {
        JOptionPane.showMessageDialog(this,"��ѡ��һ����¼");
       }
    }
}


class Search_but1_actionAdapter implements ActionListener {
    private Search adaptee;
    private ActionEvent e;
    Search_but1_actionAdapter(Search adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.but1_actionPerformed(e);
    }
}


class Search_but2_actionAdapter implements ActionListener {
    private Search adaptee;
    Search_but2_actionAdapter(Search adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}


class Search_but3_actionAdapter implements ActionListener {
    private Search adaptee;
    private ActionEvent e;
    Search_but3_actionAdapter(Search adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.but3_actionPerformed(e);
    }
}


class Search_but4_actionAdapter implements ActionListener {
    private Search adaptee;
    Search_but4_actionAdapter(Search adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but4_actionPerformed(e);
    }
}
