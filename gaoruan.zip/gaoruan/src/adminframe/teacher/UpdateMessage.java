package adminframe.teacher;

import java.awt.*;
import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jdbc.DbManager;
import java.sql.*;

public class UpdateMessage extends JFrame {

    Search s1;
    public UpdateMessage(Search main) {
        try {
            s1=main;
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("�޸Ľ�ʦ������Ϣ");
        lab.setBounds(new Rectangle(102, 13, 186, 43));
        but1.setBounds(new Rectangle(210, 355, 84, 30));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("ȡ��");
        but1.addActionListener(new UpdateMessage_but1_actionAdapter(this));
        but2.setBounds(new Rectangle(75, 355, 81, 30));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setText("ȷ��");
        but2.addActionListener(new UpdateMessage_but2_actionAdapter(this));
        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setBounds(new Rectangle(11, 59, 366, 280));
        jPanel1.setLayout(null);
        txt1.setEditable(false);
        txt1.setBackground(Color.white);   //�ı���txt1�ı���ɫ
        txt1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt1.setForeground(new Color(48, 202, 65));  //�ı���txt1��ǰ��ɫ
        txt1.setBounds(new Rectangle(121, 22, 177, 29));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt2.setBounds(new Rectangle(121, 76, 177, 29));
        txt3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt3.setBounds(new Rectangle(121, 126, 177, 29));
        jScrollPane1.setBounds(new Rectangle(121, 175, 177, 91));
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab1.setText("��ţ�");
        lab1.setBounds(new Rectangle(44, 28, 58, 25));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setText("������");
        lab2.setBounds(new Rectangle(43, 78, 65, 23));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setText("�绰��");
        lab3.setBounds(new Rectangle(43, 128, 61, 27));
        lab4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab4.setText("��ע��");
        lab4.setBounds(new Rectangle(46, 173, 50, 19));
        this.setTitle("��ʦ��Ϣ����");
        txt4.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        this.getContentPane().add(jPanel1);
        jPanel1.add(lab4);
        jPanel1.add(jScrollPane1);
        jPanel1.add(lab1);
        jPanel1.add(lab3);
        jPanel1.add(txt1);
        jPanel1.add(txt2);
        jPanel1.add(txt3);
        jPanel1.add(lab2);
        this.getContentPane().add(lab);
        jScrollPane1.getViewport().add(txt4);
    }

    JLabel lab = new JLabel();
    JButton but1 = new JButton();
    JButton but2 = new JButton();
    JPanel jPanel1 = new JPanel();
    JTextField txt1 = new JTextField();
    JTextField txt2 = new JTextField();
    JTextField txt3 = new JTextField();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTextArea txt4 = new JTextArea();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JLabel lab4 = new JLabel();


   public void setData(String id,String name,String tel,String memo)
   {
    txt1.setText(id);
    txt2.setText(name);
    txt3.setText(tel);
    txt4.setText(memo);
   }

    public void but1_actionPerformed(ActionEvent e) {
      this.setVisible(false);
    }
    DbManager db=new DbManager();
    public void but2_actionPerformed(ActionEvent e) {
       db.exec("update teacher set teacherName='"+txt2.getText().trim()+"',teacherTel='"+txt3.getText().trim()+"',memo='"+txt4.getText().trim()+"'where teacherID='"+txt1.getText()+"'");
       s1.refresh("select * from teacher");
       JOptionPane.showMessageDialog(this,"�޸ĳɹ�");
       this.setVisible(false);
   }

}


class UpdateMessage_but1_actionAdapter implements ActionListener {
    private UpdateMessage adaptee;
    UpdateMessage_but1_actionAdapter(UpdateMessage adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class UpdateMessage_but2_actionAdapter implements ActionListener {
    private UpdateMessage adaptee;
    UpdateMessage_but2_actionAdapter(UpdateMessage adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}
