package adminframe.teacher;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.BorderFactory;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import jdbc.DbManager;
import javax.swing.*;
import java.sql.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;


public class InsertMessage extends JFrame
{
     Search s1;    //����һ�����ö���
    public InsertMessage(Search main)   //main���մ������Ĵ���this
    {
       s1=main;    //����һ�����������������
        try {
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("������ʦ������Ϣ");
        lab.setBounds(new Rectangle(106, 13, 186, 43));
        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setBounds(new Rectangle(11, 59, 366, 283));
        jPanel1.setLayout(null);
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab1.setText("��ţ�");
        lab1.setBounds(new Rectangle(28, 29, 66, 30));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setText("������");
        lab2.setBounds(new Rectangle(28, 82, 62, 30));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setText("�绰��");
        lab3.setBounds(new Rectangle(28, 136, 68, 30));
        lab4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab4.setText("��ע��");
        lab4.setBounds(new Rectangle(28, 195, 61, 25));
        txt1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt1.setBounds(new Rectangle(98, 34, 200, 29));
        txt1.addFocusListener(new InsertMessage_txt1_focusAdapter(this));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt2.setBounds(new Rectangle(98, 87, 200, 29));
        txt3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt3.setBounds(new Rectangle(99, 137, 200, 29));
        jScrollPane1.setBounds(new Rectangle(97, 193, 201, 79));
        but1.setBounds(new Rectangle(75, 355, 81, 33));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("ȷ��");
        but1.addActionListener(new InsertMessage_but1_actionAdapter(this));
        but2.setBounds(new Rectangle(210, 355, 84, 34));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setText("ȡ��");
        but2.addActionListener(new InsertMessage_but2_actionAdapter(this));
        this.setTitle("��ʦ��Ϣ����");
        shuoming.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        shuoming.setText("���ֻ����T001~T999֮��");
        shuoming.setBounds(new Rectangle(102, 5, 192, 25));
        txt4.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        this.getContentPane().add(jPanel1);
        jPanel1.add(txt3);
        jPanel1.add(jScrollPane1);
        jPanel1.add(lab3);
        jPanel1.add(lab4);
        jPanel1.add(txt2);
        jPanel1.add(txt1);
        jPanel1.add(lab2);
        jPanel1.add(lab1);
        jPanel1.add(shuoming);
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        this.getContentPane().add(lab);
        jScrollPane1.getViewport().add(txt4);
    }

    JLabel lab = new JLabel();
    JPanel jPanel1 = new JPanel();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JLabel lab4 = new JLabel();
    JTextField txt1 = new JTextField();
    JTextField txt2 = new JTextField();
    JTextField txt3 = new JTextField();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTextArea txt4 = new JTextArea();
    JButton but1 = new JButton();
    JButton but2 = new JButton();

    public void but2_actionPerformed(ActionEvent e) {
      this.setVisible(false);
    }
    DbManager db=new DbManager();
    javax.swing.JLabel shuoming = new JLabel();
    public void but1_actionPerformed(ActionEvent e) {
      ResultSet rs=db.query("select * from teacher where teacherID='"+txt1.getText().trim()+"'");
    try {
        if (rs.next()) {
            JOptionPane.showMessageDialog(this, "�ñ���Ѿ����ڡ�");
            txt1.setText("");
        }else if(!(txt1.getText().trim().matches("T[0-9]*")&&txt1.getText().trim().length()==4))  //matches()�������ʽ
        {
          JOptionPane.showMessageDialog(this,"��ʽ����ȷ,��������롣");
          txt1.setText("");

        }else
        {
          db.exec("insert into teacher values('"+txt1.getText().trim()+"','"+txt2.getText().trim()+"','"+txt3.getText().trim()+"','"+txt4.getText().trim()+"')");
          s1.refresh("select * from teacher");   //ͨ������������refresh()����
          JOptionPane.showMessageDialog(this," ���ӳɹ�");
          this.setVisible(false);
        }
    } catch (SQLException ex)
    {
     System.out.println(ex.getMessage());
    }
  }

    public void txt1_focusLost(FocusEvent e)
    {
     if(!(txt1.getText().trim().matches("T[0-9]*")&&txt1.getText().trim().length()==4))  //matches()�������ʽ
     {
      shuoming.setText("��ʽ����ȷ,���������");
      shuoming.setForeground(Color.red);
     }else
     {
      shuoming.setText("��ʽ��ȷ");
      shuoming.setForeground(Color.green);
     }
    }

    public void txt1_focusGained(FocusEvent e)
    {
     shuoming.setText("���ֻ����T001��T999֮��");
     shuoming.setForeground(Color.blue);
    }
}


class InsertMessage_txt1_focusAdapter extends FocusAdapter {
    private InsertMessage adaptee;
    InsertMessage_txt1_focusAdapter(InsertMessage adaptee) {
        this.adaptee = adaptee;
    }

    public void focusLost(FocusEvent e) {
        adaptee.txt1_focusLost(e);
    }

    public void focusGained(FocusEvent e) {
        adaptee.txt1_focusGained(e);
    }
}


class InsertMessage_but2_actionAdapter implements ActionListener {
    private InsertMessage adaptee;
    private ActionEvent e;
    InsertMessage_but2_actionAdapter(InsertMessage adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.but2_actionPerformed(e);
    }
}


class InsertMessage_but1_actionAdapter implements ActionListener {
    private InsertMessage adaptee;
    private ActionEvent e;
    InsertMessage_but1_actionAdapter(InsertMessage adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.but1_actionPerformed(e);
    }
}
