package adminframe.tools;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import jdbc.DbManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.*;


public class ConfigureFrame extends JFrame {


    public ConfigureFrame() {
        try {
            jbInit();

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    public void TianJia(String ip,String user,String pwd)
    {
        txt2.setText(ip);
        txt3.setText(user);
        txt4.setText(pwd);
    }
    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        this.setTitle("����");
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 25));
        lab.setText("�� �� �� Ϣ");
        lab.setBounds(new Rectangle(97, 28, 175, 31));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setText("IP:");
        lab2.setBounds(new Rectangle(18, 80, 61, 28));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setText("�û���:");
        lab3.setBounds(new Rectangle(17, 132, 70, 32));
        lab4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab4.setText("����:");
        lab4.setBounds(new Rectangle(18, 179, 73, 33));
        txt3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt3.setBounds(new Rectangle(93, 134, 203, 26));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt2.setBounds(new Rectangle(93, 84, 203, 26));
        txt4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt4.setBounds(new Rectangle(93, 185, 203, 26));
        but1.setBounds(new Rectangle(64, 249, 71, 30));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("ȷ��");
        but1.addActionListener(new ConfigureFrame_but1_actionAdapter(this));
        but2.setBounds(new Rectangle(173, 249, 67, 30));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setText("ȡ��");
        but2.addActionListener(new ConfigureFrame_but2_actionAdapter(this));
        this.getContentPane().add(lab);
        this.getContentPane().add(lab2);
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        this.getContentPane().add(lab4);
        this.getContentPane().add(txt2);
        this.getContentPane().add(txt4);
        this.getContentPane().add(txt3);
        this.getContentPane().add(lab3);
    }

    JLabel lab = new JLabel();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JLabel lab4 = new JLabel();
    JTextField txt3 = new JTextField();
    JTextField txt2 = new JTextField();
    JTextField txt4 = new JTextField();
    JButton but1 = new JButton();
    JButton but2 = new JButton();
//    public static void main(String[] args) {
//        ConfigureFrame c=new ConfigureFrame();
//        c.setSize(350,380);
//        c.setLocation(200,110);
//        c.setVisible(true);
//        c.setResizable(false);
//    }
      DbManager db=new DbManager();
    public void but1_actionPerformed(ActionEvent e) {
    try {
        File f = new File("");
        FileWriter fw = new FileWriter(f.getAbsoluteFile() + "\\youzi.ini");

        BufferedWriter bw=new BufferedWriter(fw);
        bw.write(txt2.getText().trim().toString());
        bw.newLine();
        bw.write(txt3.getText().trim().toString());
        bw.newLine();
        bw.write(txt4.getText().trim().toString());
        bw.newLine();
        bw.flush();
        bw.close();
        JOptionPane.showMessageDialog(this,"�޸ĳɹ�");
        this.setVisible(false);
    } catch (IOException ex)
    {
        System.out.println(ex.getMessage());
    }

    }
    public void but2_actionPerformed(ActionEvent e) {
      this.setVisible(false);
    }
}


class ConfigureFrame_but1_actionAdapter implements ActionListener {
    private ConfigureFrame adaptee;
    ConfigureFrame_but1_actionAdapter(ConfigureFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class ConfigureFrame_but2_actionAdapter implements ActionListener {
    private ConfigureFrame adaptee;
    ConfigureFrame_but2_actionAdapter(ConfigureFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}
