package adminframe.tools;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
import jdbc.DbManager;
import java.awt.Rectangle;
import java.awt.Font;


public class UpdatePassword extends JFrame {
     private String user;        //����
    public UpdatePassword(String user)    //user���մ��������û���
    {
        try {
            this.user=user;     //���û���������������
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("�� �� �� ��");
        lab.setBounds(new Rectangle(100, 0, 148, 37));
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab1.setText("�����룺");
        lab1.setBounds(new Rectangle(24, 26, 72, 30));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setText("�����룺");
        lab2.setBounds(new Rectangle(24, 88, 70, 22));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setText("ȷ�����룺");
        lab3.setBounds(new Rectangle(20, 134, 65, 29));
        old.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        old.setBounds(new Rectangle(103, 25, 172, 28));
        new1.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        new1.setBounds(new Rectangle(103, 80, 172, 28));
        new2.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        new2.setToolTipText("");
        new2.setBounds(new Rectangle(103, 135, 172, 28));
        new2.addKeyListener(new UpdatePassword_new2_keyAdapter(this));
        but1.setBounds(new Rectangle(74, 233, 84, 30));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("ȷ��");
        but1.addActionListener(new UpdatePassword_but1_actionAdapter(this));
        but2.setBounds(new Rectangle(184, 232, 81, 30));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setText("ȡ��");
        but2.addActionListener(new UpdatePassword_but2_actionAdapter(this));
        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setBounds(new Rectangle(10, 38, 317, 181));
        jPanel1.setLayout(null);
        this.setTitle("�޸�����");
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        this.getContentPane().add(jPanel1);
        jPanel1.add(new1);
        jPanel1.add(new2);
        jPanel1.add(old);
        jPanel1.add(lab3);
        jPanel1.add(lab2);
        jPanel1.add(lab1);
        this.getContentPane().add(lab);
    }

    JLabel lab = new JLabel();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JPasswordField old = new JPasswordField();
    JPasswordField new1 = new JPasswordField();
    JPasswordField new2 = new JPasswordField();
    JButton but1 = new JButton();
    JButton but2 = new JButton();
    JPanel jPanel1 = new JPanel();

    public void but2_actionPerformed(ActionEvent e) {
      this.setVisible(false);
    }
    DbManager db=new DbManager();
    public void but1_actionPerformed(ActionEvent e) {
     String pwd1=String.valueOf(new1.getPassword());
     String pwd2=String.valueOf(new2.getPassword());
     if(!pwd1.equals(pwd2))
     {
      JOptionPane.showMessageDialog(this,"������֤��һ��");
      old.setText("");
      new1.setText("");
      new2.setText("");
     }else
     {
      db.exec("update userInfo set pwd='"+pwd1+"'where userName='"+user+"'");
      JOptionPane.showMessageDialog(this,"�����޸ĳɹ�");
      this.setVisible(false);
     }
    }

    public void new2_keyPressed(KeyEvent e) {
       if(e.getKeyCode()==10)     // 10 �س�����ASCII��
       {
        but1_actionPerformed(null);
       }
    }

}


class UpdatePassword_new2_keyAdapter extends KeyAdapter {
    private UpdatePassword adaptee;
    UpdatePassword_new2_keyAdapter(UpdatePassword adaptee) {
        this.adaptee = adaptee;
    }

    public void keyPressed(KeyEvent e) {
        adaptee.new2_keyPressed(e);
    }
}


class UpdatePassword_but1_actionAdapter implements ActionListener {
    private UpdatePassword adaptee;
    UpdatePassword_but1_actionAdapter(UpdatePassword adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class UpdatePassword_but2_actionAdapter implements ActionListener {
    private UpdatePassword adaptee;
    UpdatePassword_but2_actionAdapter(UpdatePassword adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}
