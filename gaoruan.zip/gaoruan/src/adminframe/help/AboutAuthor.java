package adminframe.help;

import java.awt.*;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class AboutAuthor extends JDialog {
    JPanel panel1 = new JPanel();
    JLabel about = new JLabel();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JButton but1 = new JButton();



    public AboutAuthor(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        try {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public AboutAuthor() {
        this(new Frame(), "AboutAuthor", false);
    }

    private void jbInit() throws Exception {
        panel1.setLayout(null);
        about.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        about.setForeground(new Color(113, 113, 202));
        lab1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 15));
        lab1.setForeground(new Color(179, 125, 125));
        lab1.setText("");
        lab1.setBounds(new Rectangle(66, 77, 212, 37));
        lab2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 15));
        lab2.setText("Դ�����У������޸ġ�");
        lab2.setBounds(new Rectangle(79, 128, 174, 29));
        but1.setBounds(new Rectangle(117, 176, 89, 33));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("ȷ��");
        but1.addActionListener(new AboutAuthor_but1_actionAdapter(this));
        this.setUndecorated(true);
        this.getContentPane().add(panel1, java.awt.BorderLayout.CENTER);
        panel1.add(about);
        panel1.add(lab1);
        panel1.add(but1);
        panel1.add(lab2);
        about.setText("�� �� �� ��");
        about.setBounds(new Rectangle(104, 37, 133, 31));


        this.setModal(true);
        this.setTitle("��������");
    }

    public void but1_actionPerformed(ActionEvent e) {
       this.setVisible(false);
    }
}


class AboutAuthor_but1_actionAdapter implements ActionListener {
    private AboutAuthor adaptee;
    AboutAuthor_but1_actionAdapter(AboutAuthor adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}
