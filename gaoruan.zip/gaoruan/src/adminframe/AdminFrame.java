package adminframe;

import java.awt.event.*;

import javax.swing.*;
import adminframe.user.ZhuCe;
import adminframe.help.AboutAuthor;
import adminframe.teacher.Search;
import adminframe.tools.ConfigureFrame;
import util.CenterFrame;
import util.*;
import java.awt.Font;
import teacherframe.help.AboutSoftware;
import adminframe.tools.UpdatePassword;
import java.awt.Rectangle;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import util.Logger;

public class AdminFrame extends JFrame {

    private String user;
    public AdminFrame(String user)    //user���մ��������û���
    {
        try {
            this.user=user;          //���û���������������
            jbInit();

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setJMenuBar(jMenuBar1);
        this.setTitle("�������ϵͳ");
        menu1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu1.setText("ϵͳ");
        menu2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu2.setText("�û�����");
        menu3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu3.setText("��ʦ����");
        menu4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu4.setText("����");
        menu5.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu5.setText("����");
        menuItem1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem1.setText("�˳�");
        menuItem1.addActionListener(new AdminFrame_menuItem1_actionAdapter(this));
        menuItem2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem2.setText("ע��");
        menuItem2.addActionListener(new AdminFrame_menuItem2_actionAdapter(this));
        menuItem3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem3.setText("�鿴");
        menuItem3.addActionListener(new AdminFrame_menuItem3_actionAdapter(this));
        menuItem4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem4.setText("�޸�����");
        menuItem4.addActionListener(new AdminFrame_menuItem4_actionAdapter(this));
        menuItem5.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem5.setText("��������");
        menuItem5.addActionListener(new AdminFrame_menuItem5_actionAdapter(this));
        configure.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        configure.setText("����");
        configure.addActionListener(new AdminFrame_configure_actionAdapter(this));
        jMenuItem1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        jMenuItem1.setText("��������");
        jMenuItem1.addActionListener(new AdminFrame_jMenuItem1_actionAdapter(this));
        jMenuBar1.add(menu1);
        jMenuBar1.add(menu2);
        jMenuBar1.add(menu3);
        jMenuBar1.add(menu4);
        jMenuBar1.add(menu5);
        menu1.add(menuItem1);
        menu2.add(menuItem2);
        menu3.add(menuItem3);
        menu4.add(configure);
        menu4.add(menuItem4);
        menu5.add(jMenuItem1);
        menu5.add(menuItem5);
        jLabel1.setIcon(img1);
        jLabel1.setBounds(new Rectangle( 0, 0, 800, 545));
        this.getContentPane().add(jLabel1);

        this.setUndecorated(true);//����ʾWindows������
        this.getRootPane().setWindowDecorationStyle(JRootPane.FRAME   );  //��ʾjava ������
        this.setSize(800,600);
        CenterFrame.center(this);   //�������
        this.setVisible(true);
        this.setResizable(false);

    }

    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu menu1 = new JMenu();
    JMenu menu2 = new JMenu();
    JMenu menu3 = new JMenu();
    JMenu menu4 = new JMenu();
    JMenu menu5 = new JMenu();
    JMenuItem menuItem1 = new JMenuItem();
    JMenuItem menuItem2 = new JMenuItem();
    JMenuItem menuItem3 = new JMenuItem();
    JMenuItem menuItem4 = new JMenuItem();
    JMenuItem menuItem5 = new JMenuItem();
    JMenuItem configure = new JMenuItem();
    JMenuItem jMenuItem1 = new JMenuItem();
    JLabel jLabel1 = new JLabel();
   ImageIcon img1=new ImageIcon(this.getClass().getResource("/img/adminFrame.jpg"));


    public void menuItem1_actionPerformed(ActionEvent e) {
      System.exit(0);
    }

    public void menuItem2_actionPerformed(ActionEvent e)
    {

       ZhuCe zhuce=new ZhuCe();
       zhuce.setUndecorated(true);//����ʾWindows������
       zhuce.getRootPane().setWindowDecorationStyle(JRootPane.FRAME   );  //��ʾjava ������
       zhuce.setSize(400,450);
       zhuce.setLocation(300,150);
       zhuce.setVisible(true);
       zhuce.setResizable(false);
    }

    public void menuItem3_actionPerformed(ActionEvent e)
    {

        Search search=new Search();
        search.setUndecorated(true);//����ʾWindows������
        search.getRootPane().setWindowDecorationStyle(JRootPane.FRAME   );  //��ʾjava ������
        search.setSize(450,420);
        search.setLocation(300,150);
        search.setVisible(true);
        search.setResizable(false);


    }

    public void menuItem4_actionPerformed(ActionEvent e) {
        UpdatePassword u=new UpdatePassword(user);      //����һ���µĴ��壬�����û�������ȥ
         u.setUndecorated(true);//����ʾWindows������
         u.getRootPane().setWindowDecorationStyle(JRootPane.FRAME   );  //��ʾjava ������
         u.setSize(347,300);
         u.setLocation(280,150);
         u.setVisible(true);
         u.setResizable(false);

    }

    public void menuItem5_actionPerformed(ActionEvent e)
    {

        AboutAuthor a=new AboutAuthor();

        a.getRootPane().setWindowDecorationStyle(JRootPane.FRAME   );  //��ʾjava ������
        a.setSize(350,260);
        a.setLocation(240,160);
        a.setVisible(true);


    }

    Logger log=new Logger();   //����һ����־����
    public void configure_actionPerformed(ActionEvent e)
    {
        String ip=null;
        String user=null;
        String pwd=null;

        try
              {
                  File f = new File("");
                  FileReader fr = new FileReader(f.getAbsolutePath() +"\\youzi.ini");
                  BufferedReader br = new BufferedReader(fr);
                   ip=br.readLine();
                   user=br.readLine();
                   pwd=br.readLine();
               } catch (FileNotFoundException ex)
             {
              log.log(ex.getMessage());
             }catch(Exception ex)
             {
             log.log(ex.getMessage());
             }


        ConfigureFrame c=new ConfigureFrame();
        c.setUndecorated(true);//����ʾWindows������
        c.getRootPane().setWindowDecorationStyle(JRootPane.FRAME   );  //��ʾjava ������
        c.setSize(350,380);
        c.setLocation(220,150);
        c.setVisible(true);
        c.setResizable(false);
        c.TianJia(ip,user,pwd);
        }

    public void jMenuItem1_actionPerformed(ActionEvent e) {
           AboutSoftware a=new AboutSoftware();
           a.getRootPane().setWindowDecorationStyle(JRootPane.FRAME   );  //��ʾjava ������
             a.setSize(350,300);
             a.setLocation(240,160);
             a.setVisible(true);


    }

}


class AdminFrame_jMenuItem1_actionAdapter implements ActionListener {
    private AdminFrame adaptee;
    AdminFrame_jMenuItem1_actionAdapter(AdminFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem1_actionPerformed(e);
    }
}


class AdminFrame_configure_actionAdapter implements ActionListener {
    private AdminFrame adaptee;
    AdminFrame_configure_actionAdapter(AdminFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.configure_actionPerformed(e);
    }
}


class AdminFrame_menuItem4_actionAdapter implements ActionListener {
    private AdminFrame adaptee;
    AdminFrame_menuItem4_actionAdapter(AdminFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem4_actionPerformed(e);
    }
}


class AdminFrame_menuItem5_actionAdapter implements ActionListener {
    private AdminFrame adaptee;
    AdminFrame_menuItem5_actionAdapter(AdminFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem5_actionPerformed(e);
    }
}


class AdminFrame_menuItem3_actionAdapter implements ActionListener {
    private AdminFrame adaptee;
    AdminFrame_menuItem3_actionAdapter(AdminFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem3_actionPerformed(e);
    }
}


class AdminFrame_menuItem2_actionAdapter implements ActionListener {
    private AdminFrame adaptee;
    AdminFrame_menuItem2_actionAdapter(AdminFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem2_actionPerformed(e);
    }
}


class AdminFrame_menuItem1_actionAdapter implements ActionListener {
    private AdminFrame adaptee;
    AdminFrame_menuItem1_actionAdapter(AdminFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem1_actionPerformed(e);
    }
}
