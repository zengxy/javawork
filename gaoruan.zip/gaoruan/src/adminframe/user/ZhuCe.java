package adminframe.user;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.BorderFactory;
import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import jdbc.DbManager;
import java.sql.*;

public class ZhuCe extends JFrame {


    public ZhuCe() {
        try {
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        this.setTitle("�û�ע��");
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("�� �� ע ��");
        lab.setBounds(new Rectangle(115, 29, 151, 45));
        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setBounds(new Rectangle(25, 76, 341, 276));
        jPanel1.setLayout(null);
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab1.setText("�û���:");
        lab1.setBounds(new Rectangle(35, 23, 49, 30));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setToolTipText("");
        lab2.setText("�� ��:");
        lab2.setBounds(new Rectangle(35, 78, 58, 30));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setText("ȷ������:");
        lab3.setBounds(new Rectangle(30, 125, 61, 33));
        txt1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt1.setBounds(new Rectangle(112, 26, 171, 30));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        txt2.setBounds(new Rectangle(112, 81, 171, 27));
        txt3.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        txt3.setBounds(new Rectangle(112, 129, 171, 28));
        lab4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab4.setText("Ȩ ��:");
        lab4.setBounds(new Rectangle(32, 185, 53, 34));
        jPanel2.setBorder(BorderFactory.createEtchedBorder());
        jPanel2.setBounds(new Rectangle(112, 176, 129, 92));
        jPanel2.setLayout(borderLayout1);
        rad1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        rad1.setToolTipText("");
        rad1.setSelected(true);
        rad1.setText("ѧ��");
        rad3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        rad3.setText("����Ա");
        rad2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        rad2.setText("��ʦ");
        but1.setBounds(new Rectangle(109, 370, 80, 30));
        but1.setFont(new java.awt.Font("����", Font.PLAIN, 13));
        but1.setText("ȷ��");
        but1.addActionListener(new ZhuCe_but1_actionAdapter(this));
        but2.setBounds(new Rectangle(229, 370, 80, 30));
        but2.setFont(new java.awt.Font("����", Font.PLAIN, 13));
        but2.setText("ȡ��");
        but2.addActionListener(new ZhuCe_but2_actionAdapter(this));
        this.getContentPane().add(jPanel1);
        this.getContentPane().add(lab);
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        jPanel2.add(rad3, java.awt.BorderLayout.SOUTH);
        jPanel2.add(rad1, java.awt.BorderLayout.NORTH);
        jPanel2.add(rad2, java.awt.BorderLayout.CENTER);
        jPanel1.add(lab4);
        jPanel1.add(lab1);
        jPanel1.add(lab2);
        jPanel1.add(txt1);
        jPanel1.add(txt2);
        jPanel1.add(txt3);
        jPanel1.add(lab3);
        jPanel1.add(jPanel2);
        buttonGroup1.add(rad1);
        buttonGroup1.add(rad2);
        buttonGroup1.add(rad3);
    }

    JLabel lab = new JLabel();
    JPanel jPanel1 = new JPanel();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JTextField txt1 = new JTextField();
    JPasswordField txt2 = new JPasswordField();
    JPasswordField txt3 = new JPasswordField();
    JLabel lab4 = new JLabel();
    JPanel jPanel2 = new JPanel();
    JRadioButton rad1 = new JRadioButton();
    JRadioButton rad3 = new JRadioButton();
    JRadioButton rad2 = new JRadioButton();
    BorderLayout borderLayout1 = new BorderLayout();
    ButtonGroup buttonGroup1 = new ButtonGroup();
    JButton but1 = new JButton();
    JButton but2 = new JButton();

    DbManager db=new DbManager();
    public void but1_actionPerformed(ActionEvent e)
    {
      ResultSet rs=db.query("select * from userInfo where userName='"+txt1.getText().trim()+"' ");
      String password1=String.valueOf(txt2.getPassword());   //������ת�����ַ���
      String password2=String.valueOf(txt3.getPassword());
      if(txt1.getText().trim().equals("")||password1.equals("")||password2.equals(""))
     {
     JOptionPane.showMessageDialog(this,"�û���Ϣ����Ϊ��");

     }else
     {
    try {
        if (rs.next())          //Ƕ��if
        {
          JOptionPane.showMessageDialog(this,"���û��Ѿ�����");
          txt1.setText("");
          txt2.setText("");
          txt3.setText("");
        }else
        {
         if(!password1.equals(password2))
         {
         JOptionPane.showMessageDialog(this,"�����������벻һ��");
         txt2.setText("");
         txt3.setText("");
         }else if(txt1.getText().trim().equals(password1))
         {
          JOptionPane.showMessageDialog(this,"�û��������벻����ͬ");
          txt2.setText("");
          txt3.setText("");
         }else
         {
             if(rad1.isSelected())          //����If
            {
            db.exec("insert into userInfo values('"+txt1.getText().trim()+"','"+password1+"','1')");
            JOptionPane.showMessageDialog(this,"����ѧ���ɹ�");
            this.setVisible(false);
           }else if(rad2.isSelected())
            {
                db.exec("insert into userInfo values('"+txt1.getText().trim()+"','"+password1+"','2')");
                JOptionPane.showMessageDialog(this,"������ʦ�ɹ�");
                this.setVisible(false);
            }else
            {
                db.exec("insert into userInfo values('"+txt1.getText().trim()+"','"+password1+"','3')");
                JOptionPane.showMessageDialog(this,"���ӹ���Ա�ɹ�");
                this.setVisible(false);
            }

         }
        }
    } catch (SQLException ex)
    {
     System.out.println(ex.getMessage());
    }
     }        //���if-else����

    }  //but1_actionPerformed()��������

    public void but2_actionPerformed(ActionEvent e) {
       this.setVisible(false);
    }
}


class ZhuCe_but1_actionAdapter implements ActionListener {
    private ZhuCe adaptee;
    ZhuCe_but1_actionAdapter(ZhuCe adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class ZhuCe_but2_actionAdapter implements ActionListener {
    private ZhuCe adaptee;
    ZhuCe_but2_actionAdapter(ZhuCe adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}
