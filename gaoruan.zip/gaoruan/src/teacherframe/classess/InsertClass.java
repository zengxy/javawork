package teacherframe.classess;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import jdbc.*;
import java.sql.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;


public class InsertClass extends JFrame
{
    SearchClass search;
    public InsertClass(SearchClass main)    //main���մ������Ĵ��弴
    {
        search=main;
        try {
            jbInit();
            TianJia();       //����TianJia()����
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    DbManager db=new DbManager();
    public void TianJia()         //TianJia()����
    {
     ResultSet rs=db.query("select * from teacher");      //�õ����еĽ����
    try {
        while (rs.next())
        {
         String s1=(String)rs.getString(1);     //��ȡ������ֵת�����ַ���
         String s2=(String)rs.getString(2);     //��ȡ������ֵת�����ַ���
         String s3=s1+"_"+s2+"��ʦ";         //�ַ���������
         cbo.addItem(s3);            //���ַ������ӵ���Ͽ���

        }
    } catch (SQLException ex)
    {
     System.out.println(ex.getMessage());
    }


    }
    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        this.setTitle("�༶��Ϣ����");
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("�� �� �� �� �� Ϣ");
        lab.setBounds(new Rectangle(68, 20, 188, 44));
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab1.setText("�༶��ţ�");
        lab1.setBounds(new Rectangle(27, 80, 69, 31));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setText("�����α�ţ�");
        lab2.setBounds(new Rectangle(26, 125, 81, 27));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setText("����ʱ�䣺");
        lab3.setBounds(new Rectangle(32, 177, 70, 27));
        lab4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab4.setText("�༶������");
        lab4.setBounds(new Rectangle(27, 227, 73, 29));
        lab5.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab5.setText("���ʱ�䣺");
        lab5.setBounds(new Rectangle(29, 273, 75, 29));
        lab6.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab6.setText("��ע");
        lab6.setBounds(new Rectangle(32, 321, 61, 37));
        txt1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt1.setBounds(new Rectangle(104, 80, 166, 30));
        txt1.addFocusListener(new InsertClass_txt1_focusAdapter(this));
        txt4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt4.setBounds(new Rectangle(104, 273, 166, 30));
        txt4.addFocusListener(new InsertClass_txt4_focusAdapter(this));
        txt3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt3.setBounds(new Rectangle(104, 225, 166, 30));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt2.setBounds(new Rectangle(104, 175, 166, 30));
        txt2.addFocusListener(new InsertClass_txt2_focusAdapter(this));
        cbo.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        cbo.setBounds(new Rectangle(104, 127, 167, 29));
        jScrollPane1.setBounds(new Rectangle(104, 320, 201, 85));
        but1.setBounds(new Rectangle(61, 420, 78, 34));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("ȷ��");
        but1.addActionListener(new InsertClass_but1_actionAdapter(this));
        but3.addActionListener(new InsertClass_but3_actionAdapter(this));
        but2.addActionListener(new InsertClass_but2_actionAdapter(this));
        shuoming1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        shuoming1.setForeground(Color.blue);
        shuoming1.setText("����:AJ1Q7090");
        shuoming1.setBounds(new Rectangle(279, 78, 114, 31));
        shuoming2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        shuoming2.setForeground(Color.blue);
        shuoming2.setText("����:2007-07-01");
        shuoming2.setBounds(new Rectangle(279, 175, 107, 29));
        shuoming3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        shuoming3.setForeground(Color.blue);
        shuoming3.setToolTipText("");
        shuoming3.setText("����:30");
        shuoming3.setBounds(new Rectangle(277, 224, 98, 28));
        shuoming4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        shuoming4.setForeground(Color.blue);
        shuoming4.setText("����:2007-12-20");
        shuoming4.setBounds(new Rectangle(278, 274, 106, 28));
        txt5.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but3.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        this.getContentPane().add(lab);
        but2.setBounds(new Rectangle(163, 420, 78, 34));
        but2.setText("����");
        but3.setBounds(new Rectangle(257, 420, 78, 34));
        but3.setText("�˳�");
        this.getContentPane().add(lab1);
        this.getContentPane().add(txt1);
        this.getContentPane().add(lab2);
        this.getContentPane().add(cbo);
        this.getContentPane().add(txt2);
        this.getContentPane().add(lab4);
        this.getContentPane().add(txt3);
        this.getContentPane().add(lab6);
        this.getContentPane().add(but3);
        this.getContentPane().add(but2);
        this.getContentPane().add(but1);
        this.getContentPane().add(txt4);
        this.getContentPane().add(jScrollPane1);
        this.getContentPane().add(lab3);
        this.getContentPane().add(lab5);
        this.getContentPane().add(shuoming1);
        this.getContentPane().add(shuoming2);
        this.getContentPane().add(shuoming3);
        this.getContentPane().add(shuoming4);
        jScrollPane1.getViewport().add(txt5);
    }



    JLabel lab = new JLabel();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JLabel lab4 = new JLabel();
    JLabel lab5 = new JLabel();
    JLabel lab6 = new JLabel();
    JTextField txt1 = new JTextField();
    JTextField txt4 = new JTextField();
    JTextField txt3 = new JTextField();
    JTextField txt2 = new JTextField();
    JComboBox cbo = new JComboBox();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTextArea txt5 = new JTextArea();
    JButton but3 = new JButton();
    JButton but2 = new JButton();
    JButton but1 = new JButton();
    JLabel shuoming1 = new JLabel();
    JLabel shuoming2 = new JLabel();
    JLabel shuoming3 = new JLabel();
    JLabel shuoming4 = new JLabel();
    public void but3_actionPerformed(ActionEvent e) {
      this.setVisible(false);
    }

    public void but2_actionPerformed(ActionEvent e) {
     txt1.setText("");
     txt2.setText("");
     txt3.setText("");
     txt4.setText("");
     txt5.setText("");
    }

    public void but1_actionPerformed(ActionEvent e)
    {
     ResultSet rs=db.query("select * from classInfo where classID='"+txt1.getText().trim()+"'");
     if(txt1.getText().trim().equals(""))
     {
      JOptionPane.showMessageDialog(this,"�༶��Ų���Ϊ��");
      return;                //return ���� ���ټ���ִ�������if���
     }
     if(txt2.getText().trim().equals(""))
     {
      JOptionPane.showMessageDialog(this,"����ʱ�䲻��Ϊ��");
      return ;
     }
     if(txt3.getText().trim().equals(""))
     {
      JOptionPane.showMessageDialog(this,"�༶��������Ϊ��");
      return ;
     }
     if(txt4.getText().trim().equals(""))
     {
      JOptionPane.showMessageDialog(this,"���ʱ�䲻��Ϊ��");
      return ;
     }

    try {
        if (rs.next())
        {
         JOptionPane.showMessageDialog(this,"�༶����Ѿ�����,���������");
          txt1.setText("");
        }else
        {
          String st=String.valueOf(cbo.getSelectedItem());  //���ַ���ȥ������Ͽ��������
          String ss=st.substring(0,4);         //��ȡ�ַ���
          int n=db.exec("insert into classInfo values('"+txt1.getText().trim()+"','"+ss+"','"+txt2.getText().trim()+"','"+txt3.getText().trim()+"','"+txt4.getText().trim()+"','"+txt5.getText().trim()+"')");
           if(n==1)
           {
              search.refresh("select * from classInfo");
               JOptionPane.showMessageDialog(this,"���Ӱ༶�ɹ�");
               this.setVisible(false);
           }else
           {

            shuoming1.setText("����:AJ1Q7090");
            shuoming1.setForeground(Color.red);
            shuoming2.setText("����:2007-07-01");
            shuoming2.setForeground(Color.red);
            shuoming3.setText("����:30");
            shuoming3.setForeground(Color.red);
            shuoming4.setText("����:2007-12-20");
            shuoming4.setForeground(Color.red);
            JOptionPane.showMessageDialog(this,"���Ӱ༶ʧ��,�밴�ո�ʽ����");
           }
         }
    } catch (SQLException ex)
    {
     System.out.println(ex.getMessage());
    }
    }

    public void txt1_focusGained(FocusEvent e)
    {
     shuoming1.setForeground(Color.blue);
     shuoming1.setText("����:AJ1Q7090");
     shuoming2.setForeground(Color.blue);
     shuoming2.setText("����:2007-07-01");
     shuoming3.setForeground(Color.blue);
     shuoming3.setText("����:30");
     shuoming4.setForeground(Color.blue);
      shuoming4.setText("����:2007-12-20");

    }

    public void txt1_focusLost(FocusEvent e) {
     ResultSet rs=db.query("select * from classInfo where classID='"+txt1.getText().trim()+"'");
    try {
        if (rs.next())
        {
         shuoming1.setText("�ñ���Ѿ�����");
         shuoming1.setForeground(Color.red);
        }else
        {
         if(!(txt1.getText().trim().matches("AJ[1-3]Q[0-9][0-1][0-9][0-9]")&&txt1.getText().trim().length()==8))
         {
           shuoming1.setText("��ʽ����ȷ");
           shuoming1.setForeground(Color.red);
         }else
         {
          shuoming1.setText("��ȷ");
          shuoming1.setForeground(Color.green);
         }
        }
    } catch (SQLException ex) {
    }
    }

    public void txt2_focusLost(FocusEvent e) {
     if(!(txt2.getText().trim().matches("2[0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]")))
     {
      shuoming2.setText("���ڲ���");
      shuoming2.setForeground(Color.red);
     }else
     {
      shuoming2.setText("��ȷ");
      shuoming2.setForeground(Color.green);
     }
    }

    public void txt2_focusGained(FocusEvent e) {
     shuoming2.setText("����:2007-07-01");
     shuoming2.setForeground(Color.blue);
     shuoming4.setText("����:2007-12-20");
     shuoming4.setForeground(Color.blue);
    }

    public void txt4_focusLost(FocusEvent e)
    {
        if(!(txt4.getText().trim().matches("2[0-9][0-9][0-9]-[0-1][0-9]-[0-3][0-9]")))
      {
       shuoming4.setText("���ڲ���");
       shuoming4.setForeground(Color.red);
      }else
      {
       shuoming4.setText("��ȷ");
       shuoming4.setForeground(Color.green);
      }
     }

    public void txt4_focusGained(FocusEvent e) {
     shuoming4.setText("����:2007-12-20");
     shuoming4.setForeground(Color.blue);
    }


}




class InsertClass_txt4_focusAdapter extends FocusAdapter {
    private InsertClass adaptee;
    InsertClass_txt4_focusAdapter(InsertClass adaptee) {
        this.adaptee = adaptee;
    }

    public void focusLost(FocusEvent e) {
        adaptee.txt4_focusLost(e);
    }

    public void focusGained(FocusEvent e) {
        adaptee.txt4_focusGained(e);
    }
}


class InsertClass_txt1_focusAdapter extends FocusAdapter {
    private InsertClass adaptee;
    InsertClass_txt1_focusAdapter(InsertClass adaptee) {
        this.adaptee = adaptee;
    }

    public void focusGained(FocusEvent e) {
        adaptee.txt1_focusGained(e);
    }

    public void focusLost(FocusEvent e) {
        adaptee.txt1_focusLost(e);
    }
}


class InsertClass_txt2_focusAdapter extends FocusAdapter {
    private InsertClass adaptee;
    InsertClass_txt2_focusAdapter(InsertClass adaptee) {
        this.adaptee = adaptee;
    }

    public void focusLost(FocusEvent e) {
        adaptee.txt2_focusLost(e);
    }

    public void focusGained(FocusEvent e) {
        adaptee.txt2_focusGained(e);
    }
}


class InsertClass_but1_actionAdapter implements ActionListener {
    private InsertClass adaptee;
    InsertClass_but1_actionAdapter(InsertClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class InsertClass_but3_actionAdapter implements ActionListener {
    private InsertClass adaptee;
    InsertClass_but3_actionAdapter(InsertClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but3_actionPerformed(e);
    }
}


class InsertClass_but2_actionAdapter implements ActionListener {
    private InsertClass adaptee;
    InsertClass_but2_actionAdapter(InsertClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}
