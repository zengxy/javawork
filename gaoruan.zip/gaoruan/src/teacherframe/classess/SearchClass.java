package teacherframe.classess;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.table.*;
import jdbc.DbManager;
import java.sql.ResultSet;
import java.util.Vector;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SearchClass extends JFrame {


    public SearchClass() {
        try {
            jbInit();
            refresh("select * from classInfo");
            table.setSelectionMode(0);    //ֻ��ѡ��һ����¼
            table.getTableHeader().setReorderingAllowed(false);  //���ñ�ͷ�����ƶ�
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    DbManager db=new DbManager();
    DefaultTableModel model=new DefaultTableModel();
    public void refresh(String sql)
    {
      ResultSet rs=db.query(sql);    //�õ����еĽ����
      Vector data=new Vector();
      Vector head=new Vector();
      head.add("�༶���");
      head.add("�����α��");
      head.add("����ʱ��");
      head.add("�༶����");
      head.add("���ʱ��");
      head.add("��ע");
    try {
        while (rs.next())
        {
         Vector v=new Vector();
         v.add(rs.getString(1));
         v.add(rs.getString(2));
         v.add(rs.getString(3));
         v.add(rs.getString(4));
         v.add(rs.getString(5));
         v.add(rs.getString(6));
         data.add(v);
        }
    } catch (SQLException ex)
    {
      System.out.println(ex.getMessage());
    }
      model.setDataVector(data,head);  //�����ݣ���ͷ���ӵ�ģ����
      table.setModel(model);           //��ģ�����ӵ�������
    }
    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 25));
        lab.setText("�� �� �� Ϣ �� ��");
        lab.setBounds(new Rectangle(168, 23, 243, 52));
        jScrollPane1.setBorder(BorderFactory.createEtchedBorder());
        jScrollPane1.setBounds(new Rectangle(22, 76, 641, 179));
        lab1.setFont(new java.awt.Font("������", Font.BOLD, 13));
        lab1.setText("��ѯ");
        lab1.setBounds(new Rectangle(24, 287, 52, 29));
        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setBounds(new Rectangle(22, 317, 641, 79));
        jPanel1.setLayout(null);
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setText("��ѯ����:");
        lab2.setBounds(new Rectangle(24, 25, 79, 31));
        cbo.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        cbo.setBounds(new Rectangle(104, 26, 122, 27));
        search.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        search.setBounds(new Rectangle(255, 25, 164, 28));
        but.setBounds(new Rectangle(479, 22, 97, 31));
        but.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        but.setText("��ѯ");
        but.addActionListener(new SearchClass_but_actionAdapter(this));
        but2.setBounds(new Rectangle(290, 412, 102, 38));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setText("�޸�");
        but2.addActionListener(new SearchClass_but2_actionAdapter(this));
        but3.setBounds(new Rectangle(445, 412, 102, 38));
        but3.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but3.setText("�˳�");
        but3.addActionListener(new SearchClass_but3_actionAdapter(this));
        but1.setBounds(new Rectangle(135, 412, 102, 38));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("����");
        but1.addActionListener(new SearchClass_but1_actionAdapter(this));
        this.setTitle("�༶��Ϣ����");
        this.getContentPane().add(lab);
        this.getContentPane().add(jPanel1);
        this.getContentPane().add(jScrollPane1);
        this.getContentPane().add(but3);
        this.getContentPane().add(but2);
        this.getContentPane().add(but1);
        this.getContentPane().add(lab1);
        jScrollPane1.getViewport().add(table);
        jPanel1.add(cbo);
        jPanel1.add(search);
        jPanel1.add(lab2);
        jPanel1.add(but);
    }

    JLabel lab = new JLabel();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTable table = new JTable();
    JLabel lab1 = new JLabel();
    JPanel jPanel1 = new JPanel();
    JLabel lab2 = new JLabel();

    String ss[]={"�༶���","�����α��"};
    JComboBox cbo = new JComboBox(ss);

    JTextField search = new JTextField();
    JButton but = new JButton();
    JButton but2 = new JButton();
    JButton but3 = new JButton();
    JButton but1 = new JButton();
    public void but3_actionPerformed(ActionEvent e) {
       this.setVisible(false);
    }

    public void but_actionPerformed(ActionEvent e) {
       switch(cbo.getSelectedIndex())     //�����Ͽ������
       {
         case 0:
             if(search.getText().trim().equals(""))
             {
              refresh("select * from classInfo");
             }else
             {
              ResultSet rs1=db.query("select * from classInfo where classID='"+search.getText().trim()+"'");
            try {
                if (rs1.next())
                {
                    refresh("select * from classInfo where classID='"+search.getText().trim()+"'");
                }else
                {
                 JOptionPane.showMessageDialog(this,"û������༶������²�ѯ");
                 search.setText("");
                }
            } catch (SQLException ex)
            {
             System.out.println(ex.getMessage());
            }
             }
             break;
        case 1:
            if(search.getText().trim().equals(""))
            {
             refresh("select * from classInfo");
            }else
            {
             ResultSet rs2=db.query("select * from classInfo where teacherID='"+search.getText().trim()+"'");
            try {
                if (rs2.next()) {
                    refresh("select * from classInfo where teacherID='"+search.getText().trim()+"'");

                }else
                {
                 JOptionPane.showMessageDialog(this,"�ð����α�Ų�����,����²�ѯ");
                 search.setText("");
               }
            } catch (SQLException ex1)
            {
             System.out.println(ex1.getMessage());
            }
           }
             break;
        default:

       }//end switch()
    }

    public void but1_actionPerformed(ActionEvent e) {
        InsertClass i= new InsertClass(this);
        i.setUndecorated(true);//����ʾWindows������
        i.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG );  //��ʾjava ������
        i.setSize(400,500);
        i.setLocation(260,110);
        i.setVisible(true);
        i.setResizable(false);

    }

    public void but2_actionPerformed(ActionEvent e)
    {
        int row=table.getSelectedRow();
        if(row>=0)
        {
            String classID=(String)model.getValueAt(row,0);
            String teacherID=(String)model.getValueAt(row,1);
            String startDate=(String)model.getValueAt(row,2);
            String studentCount=(String)model.getValueAt(row,3);
            String endDate=(String)model.getValueAt(row,4);
            String memo=(String)model.getValueAt(row,5);
            UpdateClass u= new UpdateClass(this);
            u.setUndecorated(true);//����ʾWindows������
            u.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG );  //��ʾjava ������
              u.setSize(400,500);
              u.setLocation(260,110);
              u.setVisible(true);
              u.setResizable(false);
              u.setData(classID,teacherID,startDate,studentCount,endDate,memo);   //����setDate()����,�����ݴ���ȥ

        }else
        {
         JOptionPane.showMessageDialog(this,"��ѡ��һ����¼");
        }


    }
}


class SearchClass_but_actionAdapter implements ActionListener {
    private SearchClass adaptee;
    SearchClass_but_actionAdapter(SearchClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but_actionPerformed(e);
    }
}


class SearchClass_but1_actionAdapter implements ActionListener {
    private SearchClass adaptee;
    SearchClass_but1_actionAdapter(SearchClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class SearchClass_but2_actionAdapter implements ActionListener {
    private SearchClass adaptee;
    SearchClass_but2_actionAdapter(SearchClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}


class SearchClass_but3_actionAdapter implements ActionListener {
    private SearchClass adaptee;
    SearchClass_but3_actionAdapter(SearchClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but3_actionPerformed(e);
    }
}
