package teacherframe.classess;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import jdbc.DbManager;
import java.sql.*;
public class UpdateClass extends JFrame {
   SearchClass search;

    public UpdateClass(SearchClass main)
    {
        search=main;
        try {
            jbInit();
            TianJia();   //����TianJia()����

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    DbManager db=new DbManager();
     public void TianJia()         //TianJia()����
     {
         ResultSet rs = db.query("select * from teacher");
         try {
             while (rs.next()) {
                 String s1=(String)rs.getString(1);
                 String s2=(String)rs.getString(2);
                 String s3=s1+"_"+s2+"��ʦ";
                 cbo.addItem(s3);       //���ַ������ӵ���Ͽ���
             }
         } catch (SQLException ex)
         {
             System.out.println(ex.getMessage());
         }
     }



    public void setData(String classID, String teacherID, String startDate,
                        String studentCount, String endDate, String memo)
    {
        String s1=teacherID;
       ResultSet rs=db.query("select * from teacher where teacherID='"+s1+"'");
        try {
            if (rs.next())
            {
             String s2=(String)rs.getString(2);
             String s3=s1+"_"+s2+"��ʦ";
             cbo.setSelectedItem(s3);      //��ĳһ��������ַ�����ʾ����Ͽ���
            }
        } catch (SQLException ex)
        {
            System.out.println(ex.getMessage());
        }


      txt1.setText(classID);

      txt2.setText(startDate);
      txt3.setText(studentCount);
      txt4.setText(endDate);
      txt5.setText(memo);

    }
       private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        lab4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab4.setText("�༶������");
        lab4.setBounds(new Rectangle(27, 227, 73, 29));
        but3.addActionListener(new UpdateClass_but3_actionAdapter(this));
        but2.addActionListener(new UpdateClass_but2_actionAdapter(this));
        txt1.setEditable(false);
        txt1.setBackground(Color.white);
        txt1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt1.setForeground(Color.orange);
        this.setTitle("�༶��Ϣ����");
        but1.addActionListener(new UpdateClass_but1_actionAdapter(this));
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab5.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab6.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        cbo.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt5.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but3.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        this.getContentPane().add(lab4);
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("�� �� �� �� �� Ϣ");
        lab.setBounds(new Rectangle(68, 20, 188, 44));
        txt3.setBounds(new Rectangle(104, 225, 166, 30));
        lab3.setText("����ʱ�䣺");
        lab3.setBounds(new Rectangle(32, 177, 70, 27));
        but2.setBounds(new Rectangle(163, 420, 78, 34));
        but2.setText("����");
        txt2.setBounds(new Rectangle(104, 175, 166, 30));
        lab2.setText("�����α�ţ�");
        lab2.setBounds(new Rectangle(26, 125, 81, 27));
        lab1.setText("�༶��ţ�");
        lab1.setBounds(new Rectangle(27, 80, 69, 31));
        but3.setBounds(new Rectangle(257, 420, 78, 34));
        but3.setText("�˳�");
        lab6.setText("��ע");
        lab6.setBounds(new Rectangle(32, 321, 61, 37));
        cbo.setBounds(new Rectangle(104, 127, 167, 29));
        txt1.setBounds(new Rectangle(104, 80, 166, 30));
        lab5.setText("���ʱ�䣺");
        lab5.setBounds(new Rectangle(29, 273, 75, 29));
        jScrollPane1.setBounds(new Rectangle(104, 320, 201, 85));
        but1.setBounds(new Rectangle(61, 420, 78, 34));
        but1.setText("ȷ��");
        this.getContentPane().add(txt4);
        this.getContentPane().add(but1);
        this.getContentPane().add(jScrollPane1);
        this.getContentPane().add(lab5);
        this.getContentPane().add(txt1);
        this.getContentPane().add(cbo);
        this.getContentPane().add(lab6);
        this.getContentPane().add(but3);
        this.getContentPane().add(lab1);
        this.getContentPane().add(lab2);
        this.getContentPane().add(txt2);
        this.getContentPane().add(but2);
        this.getContentPane().add(lab3);
        this.getContentPane().add(txt3);
        this.getContentPane().add(lab);
        jScrollPane1.getViewport().add(txt5);
        txt4.setBounds(new Rectangle(104, 273, 166, 30));
    }



    JLabel lab4 = new JLabel();
    JTextField txt4 = new JTextField();
    JButton but1 = new JButton();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTextArea txt5 = new JTextArea();
    JLabel lab5 = new JLabel();
    JTextField txt1 = new JTextField();
    JComboBox cbo = new JComboBox();
    JLabel lab6 = new JLabel();
    JButton but3 = new JButton();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JTextField txt2 = new JTextField();
    JButton but2 = new JButton();
    JLabel lab3 = new JLabel();
    JTextField txt3 = new JTextField();
    JLabel lab = new JLabel();
    public void but3_actionPerformed(ActionEvent e) {
       this.setVisible(false);
    }

    public void but2_actionPerformed(ActionEvent e) {
      txt2.setText("");
      txt3.setText("");
      txt4.setText("");
      txt5.setText("");
    }

    public void but1_actionPerformed(ActionEvent e) {
      String ss=cbo.getSelectedItem().toString().substring(0,4);  //��ȡ�ַ���
      int n=db.exec("update classInfo set teacherID='"+ss+"',startDate='"+txt2.getText().trim()+"',studentCount='"+txt3.getText().trim()+"',endDate='"+txt4.getText().trim()+"',Memo='"+txt5.getText().trim()+"'where classID='"+txt1.getText().trim()+"'");
      if(n==1)
      {
        search.refresh("select * from classInfo");
        JOptionPane.showMessageDialog(this,"�޸ĳɹ�");
        this.setVisible(false);
      }else
      {
       JOptionPane.showMessageDialog(this,"�޸�ʧ��");
      }
    }
}


class UpdateClass_but2_actionAdapter implements ActionListener {
    private UpdateClass adaptee;
    UpdateClass_but2_actionAdapter(UpdateClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}


class UpdateClass_but1_actionAdapter implements ActionListener {
    private UpdateClass adaptee;
    UpdateClass_but1_actionAdapter(UpdateClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class UpdateClass_but3_actionAdapter implements ActionListener {
    private UpdateClass adaptee;
    UpdateClass_but3_actionAdapter(UpdateClass adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but3_actionPerformed(e);
    }
}
