package teacherframe;
import adminframe.help.AboutAuthor;     //����Aboutauthor��
import java.awt.event.*;
import javax.swing.*;
import teacherframe.student.SearchStudent;
import teacherframe.classess.SearchClass;
import teacherframe.course.CourseMessage;
import teacherframe.exam.Exam;
import teacherframe.others.UpdatePasswordTeacher;
import teacherframe.help.AboutSoftware;
import util.CenterFrame;
import java.awt.Font;
import java.awt.Rectangle;


public class TeacherFrame extends JFrame {

    private String user;
    public TeacherFrame(String user)
    {
        this.user=user;
        try {
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setJMenuBar(jMenuBar1);
        this.setTitle("�������ϵͳ");
        menu1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu1.setText("ϵͳ����");
        menu2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu2.setText("ѧ������");
        menu3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu3.setText("�༶����");
        menu4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu4.setText("�γ̹���");
        menu5.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu5.setText("���Թ���");
        menu6.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu6.setText("����");
        menu7.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menu7.setText("����");
        menuItem1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem1.setText("�˳�");
        menuItem1.addActionListener(new TeacherFrame_menuItem1_actionAdapter(this));
        menItem2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menItem2.setText("�鿴ѧ����Ϣ");
        menItem2.addActionListener(new TeacherFrame_menItem2_actionAdapter(this));
        menuItem3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem3.setText("�鿴�༶��Ϣ");
        menuItem3.addActionListener(new TeacherFrame_menuItem3_actionAdapter(this));
        menuItem4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem4.setText("�鿴�γ�");
        menuItem4.addActionListener(new TeacherFrame_menuItem4_actionAdapter(this));
        menuItem5.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem5.setText("�鿴����");
        menuItem5.addActionListener(new TeacherFrame_menuItem5_actionAdapter(this));
        menuItem6.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        menuItem6.setText("�޸�����");
        menuItem6.addActionListener(new TeacherFrame_menuItem6_actionAdapter(this));
        jMenuItem7.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        jMenuItem7.setText("��������");
        jMenuItem7.addActionListener(new TeacherFrame_jMenuItem7_actionAdapter(this));
        jMenuItem8.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        jMenuItem8.setText("��������");
        jMenuItem8.addActionListener(new TeacherFrame_jMenuItem8_actionAdapter(this));
        jLabel1.setIcon(img1);
        jLabel1.setBounds(new Rectangle( 0, 0, 800, 545));
        jMenuBar1.add(menu1);
        jMenuBar1.add(menu2);
        jMenuBar1.add(menu3);
        jMenuBar1.add(menu4);
        jMenuBar1.add(menu5);
        jMenuBar1.add(menu6);
        jMenuBar1.add(menu7);
        menu1.add(menuItem1);
        menu2.add(menItem2);
        menu3.add(menuItem3);
        menu4.add(menuItem4);
        menu5.add(menuItem5);
        menu6.add(menuItem6);
        menu7.add(jMenuItem7);
        menu7.add(jMenuItem8);
        this.getContentPane().add(jLabel1);

        this.setUndecorated(true);//����ʾWindows������
        this.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG );  //��ʾjava ������
        this.setSize(800,600);
        CenterFrame.center(this);   //�������
        this.setVisible(true);
        this.setResizable(false);

    }

    JMenuBar jMenuBar1 = new JMenuBar();
    JMenu menu1 = new JMenu();
    JMenu menu2 = new JMenu();
    JMenu menu3 = new JMenu();
    JMenu menu4 = new JMenu();
    JMenu menu5 = new JMenu();
    JMenu menu6 = new JMenu();
    JMenu menu7 = new JMenu();
    JMenuItem menuItem1 = new JMenuItem();
    JMenuItem menItem2 = new JMenuItem();
    JMenuItem menuItem3 = new JMenuItem();
    JMenuItem menuItem4 = new JMenuItem();
    JMenuItem menuItem5 = new JMenuItem();
    JMenuItem menuItem6 = new JMenuItem();
    JMenuItem jMenuItem7 = new JMenuItem();
    JMenuItem jMenuItem8 = new JMenuItem();
    JLabel jLabel1 = new JLabel();
    ImageIcon img1=new ImageIcon(this.getClass().getResource("/img/teacherFrame.jpg"));

    public void menuItem1_actionPerformed(ActionEvent e) {
     System.exit(0);      //�˳�JVM
    }

    public void menItem2_actionPerformed(ActionEvent e) {
     SearchStudent s=new SearchStudent();
     s.setUndecorated(true);//����ʾWindows������
     s.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);  //��ʾjava ������
     s.setSize(700,550);
     s.setLocation(150,100);
     s.setVisible(true);
     s.setResizable(false);
    }

    public void menuItem3_actionPerformed(ActionEvent e) {
        SearchClass searchclass = new SearchClass();
        searchclass.setUndecorated(true);//����ʾWindows������
        searchclass.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);  //��ʾjava ������
        searchclass.setSize(700,500);
        searchclass.setLocation(150,110);
        searchclass.setVisible(true);
        searchclass.setResizable(false);

    }

    public void menuItem4_actionPerformed(ActionEvent e) {
        CourseMessage c = new CourseMessage();
        c.setUndecorated(true);//����ʾWindows������
        c.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);  //��ʾjava ������
            c.setSize(480,365);
            c.setLocation(200,110);
            c.setVisible(true);
            c.setResizable(false);
   }

    public void menuItem5_actionPerformed(ActionEvent e) {
        Exam exam = new Exam();
        exam.setUndecorated(true);//����ʾWindows������
        exam.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);  //��ʾjava ������
        exam.setSize(520,560);
        exam.setLocation(220,90);
        exam.setVisible(true);
        exam.setResizable(false);

    }

    public void menuItem6_actionPerformed(ActionEvent e) {
        UpdatePasswordTeacher u=new UpdatePasswordTeacher(user);      //����һ���µĴ��壬�����û�������ȥ
        u.setUndecorated(true);//����ʾWindows������
        u.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);  //��ʾjava ������
        u.setSize(330,330);
        u.setLocation(280,150);
        u.setVisible(true);
        u.setResizable(false);

    }

    public void jMenuItem8_actionPerformed(ActionEvent e) {
        AboutAuthor a=new AboutAuthor();
        a.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG );  //��ʾjava ������
        a.setSize(350,260);
        a.setLocation(240,160);
        a.setVisible(true);


    }

    public void jMenuItem7_actionPerformed(ActionEvent e) {
        AboutSoftware a=new AboutSoftware();
        a.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG );  //��ʾjava ������
        a.setSize(350,300);
        a.setLocation(240,160);
        a.setVisible(true);

    }
}


class TeacherFrame_jMenuItem8_actionAdapter implements ActionListener {
    private TeacherFrame adaptee;
    TeacherFrame_jMenuItem8_actionAdapter(TeacherFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem8_actionPerformed(e);
    }
}


class TeacherFrame_jMenuItem7_actionAdapter implements ActionListener {
    private TeacherFrame adaptee;
    TeacherFrame_jMenuItem7_actionAdapter(TeacherFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jMenuItem7_actionPerformed(e);
    }
}


class TeacherFrame_menuItem6_actionAdapter implements ActionListener {
    private TeacherFrame adaptee;
    TeacherFrame_menuItem6_actionAdapter(TeacherFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem6_actionPerformed(e);
    }
}


class TeacherFrame_menuItem5_actionAdapter implements ActionListener {
    private TeacherFrame adaptee;
    TeacherFrame_menuItem5_actionAdapter(TeacherFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem5_actionPerformed(e);
    }
}


class TeacherFrame_menuItem4_actionAdapter implements ActionListener {
    private TeacherFrame adaptee;
    TeacherFrame_menuItem4_actionAdapter(TeacherFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem4_actionPerformed(e);
    }
}


class TeacherFrame_menuItem3_actionAdapter implements ActionListener {
    private TeacherFrame adaptee;
    TeacherFrame_menuItem3_actionAdapter(TeacherFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem3_actionPerformed(e);
    }
}


class TeacherFrame_menItem2_actionAdapter implements ActionListener {
    private TeacherFrame adaptee;
    TeacherFrame_menItem2_actionAdapter(TeacherFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menItem2_actionPerformed(e);
    }
}


class TeacherFrame_menuItem1_actionAdapter implements ActionListener {
    private TeacherFrame adaptee;
    TeacherFrame_menuItem1_actionAdapter(TeacherFrame adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.menuItem1_actionPerformed(e);
    }
}
