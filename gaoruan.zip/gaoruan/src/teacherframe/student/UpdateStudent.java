package teacherframe.student;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

import javax.swing.*;

import jdbc.*;


public class UpdateStudent extends JFrame {
    SearchStudent ss;

    public UpdateStudent(SearchStudent main) {
        try {
            ss=main;
            jbInit();
            TianJia();

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
    DbManager db=new DbManager();
 public void TianJia()
 {
  ResultSet rs=db.query("select * from classInfo");   //�õ�classInfo���е����н����
 try {
     while (rs.next())               //�ж�������¼����ѭ�����ٴ�
     {
       cbo1.addItem(rs.getString(1));    //ÿѭ��һ�Σ���ÿһ����¼�еĵ�һ�����ӵ���Ͽ���
     }
 } catch (SQLException ex) {
   System.out.println(ex.getMessage());
 }
 }


   public void setData(String stuID,String stuName,String stuSex,String stuBirthday,String classID,String stuPhone,String stuInDate,String stuAddress,String memo)
   {
     txt1.setText(stuID);
     txt2.setText(stuName);
     String sex=stuSex;        //��s1ȥ���մ��������ַ���
     if(sex.equals("Ů"))
     {
         rad2.setSelected(true);
     }
     cbo1.setSelectedItem(classID);
     txt3.setText(stuBirthday);
     txt4.setText(stuPhone);
     txt5.setText(stuInDate);
     txt6.setText(stuAddress);
     txt7.setText(memo);

   }

    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("�� �� ѧ �� �� �� �� Ϣ ");
        lab.setBounds(new Rectangle(164, 22, 282, 61));
        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setBounds(new Rectangle(17, 76, 584, 356));
        jPanel1.setLayout(null);
        lab1.setText("���:");
        lab1.setBounds(new Rectangle(45, 29, 57, 36));
        txt1.setEditable(false);
        txt1.setBackground(Color.white);
        txt1.setForeground(new Color(107, 125, 167));
        txt1.setBounds(new Rectangle(108, 31, 163, 26));
        lab2.setText("������");
        lab2.setBounds(new Rectangle(323, 26, 65, 30));
        lab3.setToolTipText("");
        lab3.setText("�Ա�");
        lab3.setBounds(new Rectangle(46, 78, 53, 26));
        jPanel2.setBorder(BorderFactory.createEtchedBorder());
        jPanel2.setBounds(new Rectangle(108, 76, 163, 31));
        jPanel2.setLayout(null);
        rad1.setSelected(true);
        rad1.setText("��");
        rad1.setBounds(new Rectangle(17, 3, 39, 25));
        rad2.setText("Ů");
        rad2.setBounds(new Rectangle(81, 3, 39, 25));
        lab4.setText("���գ�");
        lab4.setBounds(new Rectangle(323, 81, 50, 29));
        txt2.setBounds(new Rectangle(377, 31, 149, 25));
        txt3.setBounds(new Rectangle(377, 82, 149, 25));
        lab5.setText("�༶:");
        lab5.setBounds(new Rectangle(46, 132, 51, 23));
        cbo1.setBounds(new Rectangle(108, 128, 163, 27));
        lab6.setText("�绰��");
        lab6.setBounds(new Rectangle(324, 131, 58, 28));
        txt4.setBounds(new Rectangle(377, 129, 149, 25));
        lab7.setText("��Уʱ�䣺");
        lab7.setBounds(new Rectangle(30, 182, 68, 24));
        txt5.setBounds(new Rectangle(108, 184, 163, 25));
        lab8.setText("��ַ:");
        lab8.setBounds(new Rectangle(324, 180, 60, 29));
        txt6.setBounds(new Rectangle(378, 182, 148, 25));
        lab9.setText("��ע��");
        lab9.setBounds(new Rectangle(45, 234, 59, 29));
        jScrollPane1.setBounds(new Rectangle(106, 240, 420, 105));
        but1.setBounds(new Rectangle(144, 455, 92, 33));
        but1.setText("ȷ��");
        but1.addActionListener(new UpdateStudent_but1_actionAdapter(this));
        but2.setBounds(new Rectangle(269, 455, 98, 33));
        but2.setText("ȡ��");
        but2.addActionListener(new UpdateStudent_but2_actionAdapter(this));
        but3.setBounds(new Rectangle(394, 455, 95, 33));
        but3.setText("����");
        but3.addActionListener(new UpdateStudent_but3_actionAdapter(this));
        this.setTitle("ѧ����Ϣ����");
        this.getContentPane().add(lab);
        this.getContentPane().add(jPanel1);
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        this.getContentPane().add(but3);
        jPanel2.add(rad2);
        jPanel2.add(rad1);
        jPanel1.add(lab8);
        jPanel1.add(txt4);
        jPanel1.add(cbo1);
        jPanel1.add(txt5);
        jPanel1.add(txt6);
        jPanel1.add(lab4);
        jPanel1.add(lab6);
        jPanel1.add(lab3);
        jPanel1.add(lab5);
        jPanel1.add(lab7);
        jPanel1.add(lab2);
        jPanel1.add(txt2);
        jPanel1.add(txt1);
        jPanel1.add(jScrollPane1);
        jPanel1.add(lab1);
        jPanel1.add(lab9);
        jPanel1.add(txt3);
        jPanel1.add(jPanel2);
        jScrollPane1.getViewport().add(txt7);
        buttonGroup1.add(rad1);
        buttonGroup1.add(rad2);
    }

    JLabel lab = new JLabel();
    JPanel jPanel1 = new JPanel();
    JLabel lab1 = new JLabel();
    JTextField txt1 = new JTextField();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JPanel jPanel2 = new JPanel();
    ButtonGroup buttonGroup1 = new ButtonGroup();
    JRadioButton rad1 = new JRadioButton();
    JRadioButton rad2 = new JRadioButton();
    JLabel lab4 = new JLabel();
    JTextField txt2 = new JTextField();
    JTextField txt3 = new JTextField();
    JLabel lab5 = new JLabel();
    JComboBox cbo1 = new JComboBox();
    JLabel lab6 = new JLabel();
    JTextField txt4 = new JTextField();
    JLabel lab7 = new JLabel();
    JTextField txt5 = new JTextField();
    JLabel lab8 = new JLabel();
    JTextField txt6 = new JTextField();
    JLabel lab9 = new JLabel();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTextArea txt7 = new JTextArea();
    JButton but1 = new JButton();
    JButton but2 = new JButton();
    JButton but3 = new JButton();
//    public static void main(String[] args) {
//        UpdateStudent u=new UpdateStudent();
//        u.setSize(620,550);
//        u.setLocation(150,120);
//        u.setVisible(true);
//        u.setResizable(false);
//    }

    public void but2_actionPerformed(ActionEvent e) {
      this.setVisible(false);
    }

    public void but3_actionPerformed(ActionEvent e) {
     txt1.setText("");
     txt2.setText("");
     txt3.setText("");
     txt4.setText("");
     txt5.setText("");
     txt6.setText("");
     txt7.setText("");
    }

    public void but1_actionPerformed(ActionEvent e)
    {
        String stuSex="";
        String s="";
      if(rad1.isSelected())
      {
         stuSex="��";
         s=String.valueOf(cbo1.getSelectedItem());
      }else
      {
       stuSex="Ů";
       s=String.valueOf(cbo1.getSelectedItem());
      }

      int n=db.exec("update student set stuName='"+txt2.getText().trim()+"',stuSex='"+stuSex+"',stuBirthday='"+txt3.getText().trim()+"',ClassID='"+s+"',stuPhone='"+txt4.getText().trim()+"',stuInDate='"+txt5.getText().trim()+"',stuAddress='"+txt6.getText().trim()+"',Memo='"+txt7.getText().trim()+"'where stuID='"+txt1.getText()+"'");
     if(n==1)
     {
         ss.refresh("select * from student");
         JOptionPane.showMessageDialog(this, "�޸ĳɹ�");
         this.setVisible(false);
     } else {
         JOptionPane.showMessageDialog(this, "�޸�ʧ��");
     }
   } //end but1_actionPerformed()

}


class UpdateStudent_but2_actionAdapter implements ActionListener {
    private UpdateStudent adaptee;
    UpdateStudent_but2_actionAdapter(UpdateStudent adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}


class UpdateStudent_but1_actionAdapter implements ActionListener {
    private UpdateStudent adaptee;
    UpdateStudent_but1_actionAdapter(UpdateStudent adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class UpdateStudent_but3_actionAdapter implements ActionListener {
    private UpdateStudent adaptee;
    UpdateStudent_but3_actionAdapter(UpdateStudent adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but3_actionPerformed(e);
    }
}
