package teacherframe.student;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.BorderFactory;
import javax.swing.table.*;
import jdbc.DbManager;
import java.sql.*;
import java.util.Vector;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;
import teacherframe.exam.Exam;


public class SearchStudent extends JFrame {


    public SearchStudent() {
        try {
            jbInit();
            refresh("select * from student");
           table.setSelectionMode(0);     //����ֻ��ѡ��һ����¼(�ڱ�����ÿ��ֻ��ѡһ����¼)
           table.getTableHeader().setReorderingAllowed(false);  //���ñ�ͷ�����ƶ�
       } catch (Exception exception) {
            exception.printStackTrace();
        }
    }
   DbManager db=new DbManager();
   DefaultTableModel model=new DefaultTableModel();
   public void refresh(String sql)
   {
    ResultSet rs=db.query(sql);   //�õ����еĽ����
    //�����������Ͽ��
    Vector data=new Vector();   //data������е�����(�������)
    Vector head=new Vector();   //head��ű�ͷ
    head.add("���");
    head.add("����");
    head.add("�Ա�");
    head.add("����");
    head.add("�༶���");
    head.add("��ϵ�绰");
    head.add("��Уʱ��");
    head.add("��ַ");
    head.add("��ע");
    try {
        while (rs.next())    //�ж�������¼����ѭ�����ٴ�
        {
            //����һ�����Ͽ��
            Vector v=new Vector();
            v.add(rs.getString(1));   //ѭ����һ��ʱ������һ�е�һ�е�ֵ���ӵ�v��
            v.add(rs.getString(2));
            v.add(rs.getString(3));
            v.add(rs.getString(4).trim().substring(0,10));   //��ȡ�ַ���
            v.add(rs.getString(5));
            v.add(rs.getString(6));
            v.add(rs.getString(7));
            v.add(rs.getString(8));
            v.add(rs.getString(9));  //ѭ����һ��ʱ������һ�еھ��е�ֵ���ӵ�v��
            data.add(v);   //��ÿһ�е��������ӵ�data��

       }
    } catch (SQLException ex)
    {
     System.out.println(ex.getMessage());
    }
    model.setDataVector(data,head);       //��data,head���ӵ�ģ����
    table.setModel(model);          //��ģ�����ӵ�������

   }


    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        this.setTitle("ѧ����Ϣ����");
        lab.setFont(new java.awt.Font("����", Font.BOLD, 22));
        lab.setText("ѧ �� �� Ϣ �� ��");
        lab.setBounds(new Rectangle(223, 15, 276, 50));
        jScrollPane1.setBorder(BorderFactory.createEtchedBorder());
        jScrollPane1.setBounds(new Rectangle(20, 70, 650, 235));
        lab1.setText("��ѯ");
        lab1.setBounds(new Rectangle(26, 327, 59, 29));
        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setBounds(new Rectangle(20, 358, 650, 75));
        jPanel1.setLayout(null);
        lab2.setText("��ѯ������");
        lab2.setBounds(new Rectangle(7, 25, 79, 25));
        cbo1.setBounds(new Rectangle(99, 27, 138, 27));
        search.setBounds(new Rectangle(275, 25, 149, 29));
        jButton1.setBounds(new Rectangle(510, 25, 79, 29));
        jButton1.setText("��ѯ");
        jButton1.addActionListener(new SearchStudent_jButton1_actionAdapter(this));
        but2.setBounds(new Rectangle(120, 456, 90, 32));
        but2.setText("����");
        but2.addActionListener(new SearchStudent_but2_actionAdapter(this));
        but3.setBounds(new Rectangle(250, 456, 88, 32));
        but3.setText("�޸�");
        but3.addActionListener(new SearchStudent_but3_actionAdapter(this));
        but4.setBounds(new Rectangle(378, 456, 84, 32));
        but4.setText("ɾ��");
        but4.addActionListener(new SearchStudent_but4_actionAdapter(this));
        but5.setBounds(new Rectangle(501, 456, 90, 32));
        but5.setText("�˳�");
        but5.addActionListener(new SearchStudent_but5_actionAdapter(this));
        this.getContentPane().add(jScrollPane1);
        this.getContentPane().add(lab1);
        this.getContentPane().add(lab);
        this.getContentPane().add(jPanel1);
        this.getContentPane().add(but5);
        this.getContentPane().add(but2);
        this.getContentPane().add(but3);
        this.getContentPane().add(but4);
        jPanel1.add(lab2);
        jPanel1.add(jButton1);
        jPanel1.add(search);
        jPanel1.add(cbo1);
        jScrollPane1.getViewport().add(table);
    }

    JLabel lab = new JLabel();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTable table = new JTable();
    JLabel lab1 = new JLabel();
    JPanel jPanel1 = new JPanel();
    JLabel lab2 = new JLabel();
    String s[]={"ѧ�����","ѧ������"};
    JComboBox cbo1 = new JComboBox(s);
    JTextField search = new JTextField();
    JButton jButton1 = new JButton();
    JButton but2 = new JButton();
    JButton but3 = new JButton();
    JButton but4 = new JButton();
    JButton but5 = new JButton();
//    public static void main(String[] args) {
//        SearchStudent s=new SearchStudent();
//        s.setSize(700,550);
//        s.setLocation(150,110);
//        s.setVisible(true);
//        s.setResizable(false);
//
//
//    }

    public void jButton1_actionPerformed(ActionEvent e)
    {
        switch(cbo1.getSelectedIndex())      //�����Ͽ������
        {
         case 0:
             if(search.getText().trim().equals(""))
             {
              refresh("select * from student");

             }else
             {
                try {
                    ResultSet rs1=db.query("select * from student where stuID='"+search.getText().trim()+"'");

                    if (rs1.next()) {
                        refresh("select * from student where stuID='" +search.getText().trim() + "'");

                    } else {
                        JOptionPane.showMessageDialog(this, "��ѧ����Ų�����");
                        search.setText("");
                    }
                }  catch (SQLException ex)
                {
                    System.out.println(ex.getMessage());
                }
              }
              break;
         case 1:
             if(search.getText().trim().equals(""))
             {
              refresh("select * from student");
             }else
             {
                 try {
                     ResultSet rs2=db.query("select * from student where stuName='"+search.getText().trim()+"'");

                     if (rs2.next())
                     {
                         refresh("select * from student where stuName='"+search.getText().trim()+"'");
                     }else
                     {
                      JOptionPane.showMessageDialog(this,"û�����ѧ��������²�ѯ��");
                      search.setText("");
                     }
                 } catch (SQLException ex1)
                 {
                  System.out.println(ex1.getMessage());
                 }
             }
             break;
            default:
                JOptionPane.showMessageDialog(this,"��ѯ����");
                break;
        } //end switch()
    }

    public void but5_actionPerformed(ActionEvent e) {
        this.setVisible(false);
    }

    public void but4_actionPerformed(ActionEvent e) {
      int row=table.getSelectedRow();          //��ȡ�кţ�������ȥ����
      if(row>=0)
      {
       String id=(String)model.getValueAt(row,0);
       int n=db.exec("delete from student where stuID='"+id+"'");    //���ݿ����stuIDΪ varchar����
          //���ɾ���ɹ����򷵻�һ����������nȥ����
       if(n==1)
        {
            refresh("select * from student");
            JOptionPane.showMessageDialog(this,"ɾ���ɹ�");
        }else
        {
           int j=JOptionPane.showConfirmDialog(this,"��ѧ��Ŀǰ�ڳɼ������м�¼\n�Ƿ�ǰ��ɾ��","ɾ����¼",JOptionPane.YES_NO_OPTION );
           if(!(j==1))
           {
               Exam exam = new Exam();
               exam.setUndecorated(true);//����ʾWindows������
               exam.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);  //��ʾjava ������
               exam.setSize(520,560);
               exam.setLocation(220,90);
               exam.setVisible(true);
               exam.setResizable(false);

           }
        }
      }else
     {
      JOptionPane.showMessageDialog(this,"��ѡ��һ����¼");
     }
    }

    public void but2_actionPerformed(ActionEvent e) {
        InsertStudent i=new InsertStudent(this);
          i.setUndecorated(true);//����ʾWindows������
          i.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);  //��ʾjava ������
           i.setSize(620,550);
           i.setLocation(150,100);
           i.setVisible(true);
           i.setResizable(false);


    }

    public void but3_actionPerformed(ActionEvent e) {
        int row=table.getSelectedRow();   //��ȡ�кţ�������ȥ����
        if(row>=0)
        {
         String stuID=(String)model.getValueAt(row,0);
         String stuName=(String)model.getValueAt(row,1);
         String stuSex=(String)model.getValueAt(row,2);
         String stuBirthday=(String)model.getValueAt(row,3);
         String classID=(String)model.getValueAt(row,4);
         String stuPhone=(String)model.getValueAt(row,5);
         String stuInDate=(String)model.getValueAt(row,6);
         String stuAddress=(String)model.getValueAt(row,7);
         String memo=(String)model.getValueAt(row,8);
         UpdateStudent u=new UpdateStudent(this);
         u.setUndecorated(true);//����ʾWindows������
         u.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);  //��ʾjava ������
         u.setSize(620,550);
         u.setLocation(150,100);
         u.setVisible(true);
         u.setResizable(false);
         u.setData(stuID,stuName,stuSex,stuBirthday,classID,stuPhone,stuInDate,stuAddress,memo);

        }else
        {
         JOptionPane.showMessageDialog(this,"��ѡ��һ����¼");
        }
    }
}


class SearchStudent_but4_actionAdapter implements ActionListener {
    private SearchStudent adaptee;
    SearchStudent_but4_actionAdapter(SearchStudent adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but4_actionPerformed(e);
    }
}


class SearchStudent_but2_actionAdapter implements ActionListener {
    private SearchStudent adaptee;
    SearchStudent_but2_actionAdapter(SearchStudent adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}


class SearchStudent_but3_actionAdapter implements ActionListener {
    private SearchStudent adaptee;
    SearchStudent_but3_actionAdapter(SearchStudent adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but3_actionPerformed(e);
    }
}


class SearchStudent_jButton1_actionAdapter implements ActionListener {
    private SearchStudent adaptee;
    SearchStudent_jButton1_actionAdapter(SearchStudent adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.jButton1_actionPerformed(e);
    }
}


class SearchStudent_but5_actionAdapter implements ActionListener {
    private SearchStudent adaptee;
    SearchStudent_but5_actionAdapter(SearchStudent adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but5_actionPerformed(e);
    }
}
