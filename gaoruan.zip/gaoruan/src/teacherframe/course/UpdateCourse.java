package teacherframe.course;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import jdbc.DbManager;

public class UpdateCourse extends JFrame {

     CourseMessage cc;
    public UpdateCourse(CourseMessage main)    //main���մ������Ĵ������
    {
        cc=main;
        try {
            jbInit();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public void setData(String courseID,String courseName,String memo)   //setData() ����
    {
     txt1.setText(courseID);      //txt1���մ�������courseID
     txt2.setText(courseName);    //txt2���մ�������courseName
     txt3.setText(memo);         //txt3���մ�������memo
    }
    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setToolTipText("");
        lab.setText("�� �� �� �� �� Ϣ");
        lab.setBounds(new Rectangle(97, 20, 195, 51));
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab1.setText("�γ̱��:");
        lab1.setBounds(new Rectangle(41, 70, 67, 34));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setText("�γ�����:");
        lab2.setBounds(new Rectangle(43, 124, 65, 34));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setToolTipText("");
        lab3.setText("�γ̱�ע:");
        lab3.setBounds(new Rectangle(41, 180, 65, 34));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt2.setBounds(new Rectangle(112, 126, 184, 32));
        txt1.setEditable(false);
        txt1.setBackground(Color.white);
        txt1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt1.setForeground(Color.cyan);

        txt1.setBounds(new Rectangle(112, 73, 184, 32));
        jScrollPane1.setBounds(new Rectangle(110, 180, 230, 102));
        but3.setBounds(new Rectangle(289, 316, 76, 32));
        but3.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but3.setText("����");
        but3.addActionListener(new UpdateCourse_but3_actionAdapter(this));

        but1.setBounds(new Rectangle(100, 317, 76, 32));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("ȷ��");
        but1.addActionListener(new UpdateCourse_but1_actionAdapter(this));

        but2.setBounds(new Rectangle(192, 317, 76, 32));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setText("ȡ��");
        but2.addActionListener(new UpdateCourse_but2_actionAdapter(this));
        this.setTitle("�γ���Ϣ����");
        txt3.setFont(new java.awt.Font("������", Font.PLAIN, 14));

        this.getContentPane().add(lab);
        this.getContentPane().add(lab1);
        this.getContentPane().add(txt1);
        this.getContentPane().add(txt2);
        this.getContentPane().add(jScrollPane1);
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        this.getContentPane().add(but3);
        this.getContentPane().add(lab2);
        this.getContentPane().add(lab3);
        jScrollPane1.getViewport().add(txt3);
    }

//    public static void main(String[] args) {
//        UpdateCourse u = new UpdateCourse();
//        u.setSize(450,400);
//        u.setLocation(200,110);
//        u.setVisible(true);
//        u.setResizable(false);
//    }

    JLabel lab = new JLabel();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JTextField txt2 = new JTextField();
    JTextField txt1 = new JTextField();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTextArea txt3 = new JTextArea();
    JButton but3 = new JButton();
    JButton but1 = new JButton();
    JButton but2 = new JButton();
    public void but3_actionPerformed(ActionEvent e) {

       txt2.setText("");
       txt3.setText("");
    }

    public void but2_actionPerformed(ActionEvent e) {
      this.setVisible(false);
    }

     DbManager db=new DbManager();
    public void but1_actionPerformed(ActionEvent e)
    {
        if(txt2.getText().trim().equals(""))
        {
         JOptionPane.showMessageDialog(this,"�γ����Ʋ���Ϊ��");
         return;
        }
     db.exec("update course set courseName='"+txt2.getText().trim()+"',memo='"+txt3.getText().trim()+"'where courseID='"+txt1.getText().trim()+"'");
     cc.refresh("select * from course");
     JOptionPane.showMessageDialog(this,"�޸ĳɹ�");
     this.setVisible(false);
    }
  }


class UpdateCourse_but1_actionAdapter implements ActionListener {
    private UpdateCourse adaptee;
    UpdateCourse_but1_actionAdapter(UpdateCourse adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class UpdateCourse_but2_actionAdapter implements ActionListener {
    private UpdateCourse adaptee;
    UpdateCourse_but2_actionAdapter(UpdateCourse adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}


class UpdateCourse_but3_actionAdapter implements ActionListener {
    private UpdateCourse adaptee;
    UpdateCourse_but3_actionAdapter(UpdateCourse adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but3_actionPerformed(e);
    }
}

