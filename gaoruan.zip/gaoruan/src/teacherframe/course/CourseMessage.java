package teacherframe.course;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.BorderFactory;
import jdbc.DbManager;
import java.sql.*;
import java.util.*;
import javax.swing.table.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import teacherframe.exam.Exam;

public class CourseMessage extends JFrame {


    public CourseMessage() {
        try {
            jbInit();
            refresh("select * from course");
            table.setSelectionMode(0);       //ÿ��ֻ��ѡ��һ����¼
            table.getTableHeader().setReorderingAllowed(false);  //���ñ�ͷ�����ƶ�
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    DbManager db=new DbManager();
    DefaultTableModel model=new DefaultTableModel();
    public void refresh(String sql)
    {
     ResultSet rs=db.query(sql);     //�õ����еĽ����
     Vector data=new Vector();
     Vector head=new Vector();
     head.add("�γ̱��");
     head.add("�γ�����");
     head.add("�γ̱�ע");
    try {
        while (rs.next())
        {
           Vector v=new Vector();
            v.add(rs.getString(1));
            v.add(rs.getString(2));
            v.add(rs.getString(3));
            data.add(v);        //��ÿһ����¼���ӵ�data��
        }
    } catch (SQLException ex)
    {
     System.out.println(ex.getMessage());
    }

       model.setDataVector(data,head);         //������ ��ͷ ���ӵ�ģ����
       table.setModel(model);    //��ģ�����ӵ�������

   }


    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("�� �� �� Ϣ �� ��");
        lab.setBounds(new Rectangle(137, 17, 194, 56));
        jScrollPane1.setBorder(BorderFactory.createEtchedBorder());
        jScrollPane1.setBounds(new Rectangle(17, 83, 442, 181));
        but2.setBounds(new Rectangle(141, 282, 84, 34));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setText("�޸�");
        but2.addActionListener(new CourseMessage_but2_actionAdapter(this));
        but3.setBounds(new Rectangle(246, 282, 84, 34));
        but3.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but3.setText("ɾ��");
        but3.addActionListener(new CourseMessage_but3_actionAdapter(this));
        but4.setBounds(new Rectangle(354, 282, 84, 34));
        but4.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but4.setText("�˳�");
        but4.addActionListener(new CourseMessage_but4_actionAdapter(this));
        but1.setBounds(new Rectangle(31, 282, 84, 34));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("����");
        but1.addActionListener(new CourseMessage_but1_actionAdapter(this));
        this.setTitle("�γ���Ϣ����");
        this.getContentPane().add(jScrollPane1);
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        this.getContentPane().add(but3);
        this.getContentPane().add(but4);
        this.getContentPane().add(lab);
        jScrollPane1.getViewport().add(table);
    }

    JLabel lab = new JLabel();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTable table = new JTable();
    JButton but2 = new JButton();
    JButton but3 = new JButton();
    JButton but4 = new JButton();
    JButton but1 = new JButton();
    public void but4_actionPerformed(ActionEvent e) {
      this.setVisible(false);
    }

    public void but3_actionPerformed(ActionEvent e) {
      int row=table.getSelectedRow();     //��ȡ�кţ�������ȥ����
      if(row>=0)
      {
       String id=(String)model.getValueAt(row,0);
       int n=db.exec("delete  from course where courseID='"+id+"'");
       if(n==1)
       {
         refresh("select * from course");
         JOptionPane.showMessageDialog(this,"ɾ���ɹ�");
       }else
       {
         int j=JOptionPane.showConfirmDialog(this,"�ÿγ�Ŀǰ�ڳɼ������м�¼\n�Ƿ�ǰ��ɾ��","ɾ����¼",JOptionPane.YES_NO_OPTION );
         if(!(j==1))
         {
             Exam exam = new Exam();
             exam.setUndecorated(true);//����ʾWindows������
             exam.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG);  //��ʾjava ������
             exam.setSize(520,560);
             exam.setLocation(220,90);
             exam.setVisible(true);
             exam.setResizable(false);

         }
       }
      }else
      {
       JOptionPane.showMessageDialog(this,"��ѡ��һ����¼");
      }
    }

    public void but1_actionPerformed(ActionEvent e) {
        InsertCourse i = new InsertCourse(this);
        i.setUndecorated(true);//����ʾWindows������
        i.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG );  //��ʾjava ������
        i.setSize(450,400);
        i.setLocation(200,110);
        i.setVisible(true);
        i.setResizable(false);


    }

    public void but2_actionPerformed(ActionEvent e) {
        int row=table.getSelectedRow();         //��ȡ�кţ�������ȥ����
        if(row>=0)
        {
            String courseID = (String) model.getValueAt(row, 0);
            String courseName = (String) model.getValueAt(row, 1);
            String memo = (String) model.getValueAt(row, 2);
            UpdateCourse u = new UpdateCourse(this);
            u.setUndecorated(true);//����ʾWindows������
            u.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG );  //��ʾjava ������
            u.setSize(450, 400);
            u.setLocation(200, 110);
            u.setVisible(true);
            u.setResizable(false);
            u.setData(courseID,courseName,memo);   //����setData()�����������ݴ���ȥ

        }else
        {
         JOptionPane.showMessageDialog(this,"��ѡ��һ����¼");
        }
    }
}


class CourseMessage_but3_actionAdapter implements ActionListener {
    private CourseMessage adaptee;
    CourseMessage_but3_actionAdapter(CourseMessage adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but3_actionPerformed(e);
    }
}


class CourseMessage_but1_actionAdapter implements ActionListener {
    private CourseMessage adaptee;
    CourseMessage_but1_actionAdapter(CourseMessage adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class CourseMessage_but2_actionAdapter implements ActionListener {
    private CourseMessage adaptee;
    CourseMessage_but2_actionAdapter(CourseMessage adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}


class CourseMessage_but4_actionAdapter implements ActionListener {
    private CourseMessage adaptee;
    CourseMessage_but4_actionAdapter(CourseMessage adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but4_actionPerformed(e);
    }
}
