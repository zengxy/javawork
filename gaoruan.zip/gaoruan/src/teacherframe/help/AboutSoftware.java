package teacherframe.help;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.event.FocusEvent;
import java.awt.event.FocusAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;


public class AboutSoftware extends JDialog {
    JPanel panel1 = new JPanel();
    JLabel shuoming = new JLabel();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JLabel lab4 = new JLabel();
    JButton but1 = new JButton();
    JLabel time = new JLabel();
    JLabel gaozhi = new JLabel();
    JLabel qq1 = new JLabel();
    JLabel qq2 = new JLabel();


    public AboutSoftware(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        try {
            setDefaultCloseOperation(DISPOSE_ON_CLOSE);
            jbInit();
            pack();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public AboutSoftware() {
        this(new Frame(), "AboutSoftware", false);
    }

    private void jbInit() throws Exception {
        panel1.setLayout(null);
        this.setModal(true);
        this.setTitle("��������");
        this.setUndecorated(true);
        shuoming.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 25));
        shuoming.setBorder(BorderFactory.createEtchedBorder());
        shuoming.setText("�������ϵͳV1.0��");
        shuoming.setBounds(new Rectangle(37, 20, 246, 40));
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab1.setText("��������ʵ�ֻ����Ľ������");
        lab1.setBounds(new Rectangle(67, 69, 201, 37));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setText("�����ʹ�ù�����,���ִ�������.");
        lab2.setBounds(new Rectangle(62, 101, 223, 33));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setText("E-mail:");
        lab3.setBounds(new Rectangle(52, 194, 63, 26));
        lab4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab4.setForeground(Color.blue);
        lab4.setText("youzi1106@126.com");
        lab4.setBounds(new Rectangle(120, 191, 151, 29));
        lab4.addMouseListener(new AboutSoftware_lab4_mouseAdapter(this));
        but1.setBounds(new Rectangle(101, 232, 76, 29));
        but1.setText("ȷ��");
        but1.addActionListener(new AboutSoftware_but1_actionAdapter(this));
        time.setFont(new java.awt.Font("����", Font.BOLD, 13));
        time.setForeground(new Color(77, 167, 137));
        time.setToolTipText("");
        time.setText("2007��12��3�� ���");
        time.setBounds(new Rectangle(195, 238, 155, 26));
        time.addMouseListener(new AboutSoftware_time_mouseAdapter(this));
        gaozhi.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        gaozhi.setText("����ϵ���߽������ӻ򷢵����ʼ�.");
        gaozhi.setBounds(new Rectangle(64, 129, 214, 30));
        qq1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        qq1.setText("QQ:");
        qq1.setBounds(new Rectangle(71, 162, 38, 27));
        qq2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        qq2.setForeground(Color.blue);
        qq2.setText("119623061");
        qq2.setBounds(new Rectangle(127, 165, 92, 26));
        qq2.addMouseListener(new AboutSoftware_qq2_mouseAdapter(this));
        getContentPane().add(panel1);
        panel1.add(shuoming);
        panel1.add(but1);
        panel1.add(lab4);
        panel1.add(lab3);
        panel1.add(qq2);
        panel1.add(lab1);
        panel1.add(lab2);
        panel1.add(gaozhi);
        panel1.add(qq1);
        panel1.add(time);
    }

    public void lab4_mouseEntered(MouseEvent e) {
        lab4.setCursor(Cursor.getPredefinedCursor(12));
        lab4.setForeground(Color.red);
    }

    public void lab4_mouseExited(MouseEvent e) {
       lab4.setForeground(Color.BLUE);
    }

    public void but1_actionPerformed(ActionEvent e) {
      this.setVisible(false);
    }

    public void qq2_mouseEntered(MouseEvent e) {
       qq2.setForeground(Color.red);

    }

    public void qq2_mouseExited(MouseEvent e) {
      qq2.setForeground(Color.blue);
    }

    public void time_mouseEntered(MouseEvent e) {
     time.setForeground(Color.cyan);
    }

    public void time_mouseExited(MouseEvent e) {
     time.setForeground(new Color(77,167,137));
    }
}


class AboutSoftware_time_mouseAdapter extends MouseAdapter {
    private AboutSoftware adaptee;
    AboutSoftware_time_mouseAdapter(AboutSoftware adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.time_mouseEntered(e);
    }

    public void mouseExited(MouseEvent e) {
        adaptee.time_mouseExited(e);
    }
}


class AboutSoftware_qq2_mouseAdapter extends MouseAdapter {
    private AboutSoftware adaptee;
    AboutSoftware_qq2_mouseAdapter(AboutSoftware adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.qq2_mouseEntered(e);
    }

    public void mouseExited(MouseEvent e) {
        adaptee.qq2_mouseExited(e);
    }
}


class AboutSoftware_but1_actionAdapter implements ActionListener {
    private AboutSoftware adaptee;
    AboutSoftware_but1_actionAdapter(AboutSoftware adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class AboutSoftware_lab4_mouseAdapter extends MouseAdapter {
    private AboutSoftware adaptee;
    AboutSoftware_lab4_mouseAdapter(AboutSoftware adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseEntered(MouseEvent e) {
        adaptee.lab4_mouseEntered(e);
    }

    public void mouseExited(MouseEvent e) {
        adaptee.lab4_mouseExited(e);
    }
}
