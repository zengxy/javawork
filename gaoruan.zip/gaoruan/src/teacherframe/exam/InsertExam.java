package teacherframe.exam;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import jdbc.DbManager;

public class InsertExam extends JFrame
{
     Exam exam;
     public InsertExam(Exam main)
     {
         exam=main;
        try {
            jbInit();
            TianJia();      //����TianJia()����
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    DbManager db=new DbManager();
    public void TianJia()
    {
     ResultSet rs=db.query("select * from course");
    try {
        while (rs.next()) {
           String s1=(String)rs.getString(1);
           String s2=(String)rs.getString(2);
           String s3=s1+"_"+s2;
           cbo.addItem(s3);         //���ַ������ӵ���Ͽ���
        }
    } catch (SQLException ex)
    {
     System.out.println(ex.getMessage());
    }
    }
    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        this.setTitle("���Գɼ�����");
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 20));
        lab.setText("�� �� �� �� �� ��");
        lab.setBounds(new Rectangle(103, 36, 190, 47));
        lab4.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab4.setText("���Գɼ�:");
        lab4.setBounds(new Rectangle(38, 248, 66, 27));
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab1.setText("ѧ�����:");
        lab1.setBounds(new Rectangle(38, 100, 66, 27));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab2.setText("�γ̱��:");
        lab2.setBounds(new Rectangle(38, 150, 66, 27));
        lab3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab3.setText("���Գɼ�:");
        lab3.setBounds(new Rectangle(38, 198, 66, 27));
        txt3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt3.setBounds(new Rectangle(132, 246, 171, 28));
        txt1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt1.setBounds(new Rectangle(132, 100, 171, 28));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt2.setBounds(new Rectangle(132, 197, 171, 28));
        cbo.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        cbo.setBounds(new Rectangle(132, 151, 169, 27));
        but3.setBounds(new Rectangle(254, 305, 79, 33));
        but3.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but3.setText("����");
        but3.addActionListener(new InsertExam_but3_actionAdapter(this));
        but1.setBounds(new Rectangle(51, 305, 79, 33));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but1.setText("ȷ��");
        but1.addActionListener(new InsertExam_but1_actionAdapter(this));
        but2.setBounds(new Rectangle(151, 305, 79, 33));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setText("ȡ��");
        but2.addActionListener(new InsertExam_but2_actionAdapter(this));
        this.getContentPane().add(lab);
        this.getContentPane().add(but1);
        this.getContentPane().add(but2);
        this.getContentPane().add(but3);
        this.getContentPane().add(txt1);
        this.getContentPane().add(txt3);
        this.getContentPane().add(lab4);
        this.getContentPane().add(lab3);
        this.getContentPane().add(lab2);
        this.getContentPane().add(lab1);
        this.getContentPane().add(txt2);
        this.getContentPane().add(cbo);
    }

    JLabel lab = new JLabel();
    JLabel lab4 = new JLabel();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JLabel lab3 = new JLabel();
    JTextField txt3 = new JTextField();
    JTextField txt1 = new JTextField();
    JTextField txt2 = new JTextField();
    JComboBox cbo = new JComboBox();
    JButton but3 = new JButton();
    JButton but1 = new JButton();
    JButton but2 = new JButton();
    public void but3_actionPerformed(ActionEvent e) {
     txt1.setText("");
     txt2.setText("");
     txt3.setText("");
    }

    public void but2_actionPerformed(ActionEvent e) {
     this.setVisible(false);
    }

    public void but1_actionPerformed(ActionEvent e) {
        if(txt1.getText().trim().equals(""))
        {
         JOptionPane.showMessageDialog(this,"ѧ����Ų���Ϊ��");
         return ;
        }
        if(txt2.getText().trim().equals(""))
        {
        JOptionPane.showMessageDialog(this,"���Գɼ�����Ϊ��");
        return ;
        }
        if(txt3.getText().trim().equals(""))
        {
         JOptionPane.showMessageDialog(this,"���Գɼ�����Ϊ��");
         return ;
        }

        try {
            Integer i = Integer.parseInt(txt2.getText().trim());
            if (i >= 100) {
                JOptionPane.showMessageDialog(this, "���Գɼ����ܴ���100");
                return;
            }
            Integer j = Integer.parseInt(txt3.getText().trim());
            if (j >= 100) {
                JOptionPane.showMessageDialog(this, "���Գɼ����ܴ���100");
                return;
            }
        }
       catch (NumberFormatException ex)
       {
           System.out.println(ex.getMessage());
           JOptionPane.showMessageDialog(this,"�ɼ�ֻ��Ϊ����");
           return;
        }
        String ss=(String)cbo.getSelectedItem();   //��ѡ�е���Ͽ��������ת�����ַ���
        String sss=ss.substring(0,4);   //��ȡ�ַ���
        int n=db.exec("insert into exam values('"+txt1.getText().trim()+"','"+sss+"','"+txt2.getText().trim()+"','"+txt3.getText().trim()+"')");
        if(n==1)
        {
            exam.refresh("select * from exam");
            JOptionPane.showMessageDialog(this,"���ӳɹ�");
            this.setVisible(false);

        }else
        {
         JOptionPane.showMessageDialog(this,"����ʧ��");
        }
    }
}


class InsertExam_but1_actionAdapter implements ActionListener {
    private InsertExam adaptee;
    InsertExam_but1_actionAdapter(InsertExam adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class InsertExam_but3_actionAdapter implements ActionListener {
    private InsertExam adaptee;
    InsertExam_but3_actionAdapter(InsertExam adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but3_actionPerformed(e);
    }
}


class InsertExam_but2_actionAdapter implements ActionListener {
    private InsertExam adaptee;
    InsertExam_but2_actionAdapter(InsertExam adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}
