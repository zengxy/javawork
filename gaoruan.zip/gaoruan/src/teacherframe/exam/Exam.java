package teacherframe.exam;

import java.awt.*;

import javax.swing.*;
import java.awt.Rectangle;
import java.awt.Font;
import javax.swing.BorderFactory;
import jdbc.DbManager;
import javax.swing.table.*;
import java.util.Vector;
import java.sql.ResultSet;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Exam extends JFrame {


    public Exam() {
        try {
            jbInit();
            refresh("select * from exam");
            table.setSelectionMode(0);    //����ֻ��ѡ��һ����¼
            table.getTableHeader().setReorderingAllowed(false);  //���ñ�ͷ�����ƶ�
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    DbManager db=new DbManager();
    DefaultTableModel model=new DefaultTableModel();        //����һ��ģ��
    public void refresh(String sql)
    {
      ResultSet rs=db.query(sql);  //�õ����еĽ����
      Vector data=new Vector();
      Vector head=new Vector();
      head.add("���Ա��");
      head.add("ѧ�����");
      head.add("�γ̱��");
      head.add("���Գɼ�");
      head.add("���Գɼ�");
    try {
        while (rs.next())
        {
         Vector v=new Vector();
         v.add(rs.getString(1));
         v.add(rs.getString(2));
         v.add(rs.getString(3));
         v.add(rs.getString(4));
         v.add(rs.getString(5));
         data.add(v);         //��ÿ����¼���ӵ�data��
       }
    } catch (SQLException ex)
    {
     System.out.println(ex.getMessage());
    }

    model.setDataVector(data,head);    //������ ��ͷ ���ӵ�ģ����
    table.setModel(model);             //��ģ�����ӵ�������
  }
    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        this.setTitle("���Գɼ�����");
        lab.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 25));
        lab.setText("�� �� �� �� �� ��");
        lab.setBounds(new Rectangle(169, 16, 226, 44));
        jScrollPane1.setBorder(BorderFactory.createEtchedBorder());
        jScrollPane1.setBounds(new Rectangle(10, 59, 492, 241));
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        lab1.setText("��ѯ:");
        lab1.setBounds(new Rectangle(10, 314, 56, 31));
        but3.setBounds(new Rectangle(80, 489, 78, 32));
        but3.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but3.setText("����");
        but3.addActionListener(new Exam_but3_actionAdapter(this));
        but2.addActionListener(new Exam_but2_actionAdapter(this));
        but5.addActionListener(new Exam_but5_actionAdapter(this));
        but4.addActionListener(new Exam_but4_actionAdapter(this));
        but1.addActionListener(new Exam_but1_actionAdapter(this));
        chk1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        chk3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt1.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt3.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        chk2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        but1.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but2.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but4.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        but5.setFont(new java.awt.Font("����_GB2312", Font.BOLD, 13));
        this.getContentPane().add(lab);
        chk1.setText("���Ա��");
        chk1.setBounds(new Rectangle(23, 28, 80, 25));
        txt1.setBounds(new Rectangle(119, 26, 91, 26));
        chk2.setText("ѧ�����");
        chk2.setBounds(new Rectangle(274, 28, 87, 21));
        txt2.setBounds(new Rectangle(369, 26, 96, 26));
        chk3.setText("�γ̱��");
        chk3.setBounds(new Rectangle(23, 79, 83, 22));
        txt3.setBounds(new Rectangle(119, 79, 90, 26));
        but1.setBounds(new Rectangle(262, 79, 74, 30));
        but1.setText("��ѯ");
        but2.setBounds(new Rectangle(377, 79, 71, 30));
        but2.setText("����");
        but4.setBounds(new Rectangle(203, 489, 74, 32));
        but4.setText("ɾ��");
        but5.setBounds(new Rectangle(322, 489, 75, 32));
        but5.setText("�˳�");
        jPanel1.add(but1);
        jPanel1.add(but2);
        jPanel1.add(txt3);
        jPanel1.add(txt1);
        jPanel1.add(chk3);
        jPanel1.add(chk1);
        jPanel1.add(chk2);
        jPanel1.add(txt2);
        this.getContentPane().add(lab1);
        this.getContentPane().add(but3);
        this.getContentPane().add(but4);
        this.getContentPane().add(but5);
        this.getContentPane().add(jScrollPane1);
        this.getContentPane().add(jPanel1);
        jScrollPane1.getViewport().add(table);
        jPanel1.setLayout(null);

        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setBounds(new Rectangle(10, 344, 492, 125));

    }


    JLabel lab = new JLabel();
    JScrollPane jScrollPane1 = new JScrollPane();
    JTable table = new JTable();
    JLabel lab1 = new JLabel();
    JPanel jPanel1 = new JPanel();
    JCheckBox chk1 = new JCheckBox();
    JTextField txt1 = new JTextField();
    JCheckBox chk2 = new JCheckBox();
    JTextField txt2 = new JTextField();
    JCheckBox chk3 = new JCheckBox();
    JTextField txt3 = new JTextField();
    JButton but1 = new JButton();
    JButton but2 = new JButton();
    JButton but4 = new JButton();
    JButton but5 = new JButton();
    JButton but3 = new JButton();
    public void but2_actionPerformed(ActionEvent e) {
     txt1.setText("");
     txt2.setText("");
     txt3.setText("");
     chk1.setSelected(false);
     chk2.setSelected(false);
     chk3.setSelected(false);
    }

    public void but5_actionPerformed(ActionEvent e) {
     this.setVisible(false);
    }

    public void but4_actionPerformed(ActionEvent e) {
      int row=table.getSelectedRow();     //��ȡ�кţ�������ȥ����
      if(row>=0)
      {
       String id=(String)model.getValueAt(row,0);
       db.exec("delete from exam where examID="+id);
        refresh("select * from exam");
       JOptionPane.showMessageDialog(this,"ɾ���ɹ�");

      }else
      {
       JOptionPane.showMessageDialog(this,"��ѡ��һ����¼");
      }
    }

    public void but3_actionPerformed(ActionEvent e) {
        InsertExam i = new InsertExam(this);
        i.setUndecorated(true);//����ʾWindows������
        i.getRootPane().setWindowDecorationStyle(JRootPane.FILE_CHOOSER_DIALOG );  //��ʾjava ������
        i.setSize(400,400);
        i.setLocation(200,110);
        i.setVisible(true);
        i.setResizable(false);

    }

    public void but1_actionPerformed(ActionEvent e)
    {
        if(chk1.isSelected())
        {
          if(chk2.isSelected()&&!chk3.isSelected())
          {
           refresh("select * from exam where examID='"+txt1.getText().trim()+"'and stuID='"+txt2.getText().trim()+"'");

          }else if(chk3.isSelected()&&!chk2.isSelected())
          {
           refresh("select * from exam where examID='"+txt1.getText().trim()+"'and courseID='"+txt3.getText().trim()+"'");
          }else if(!(chk2.isSelected()&&chk3.isSelected()))
          {
           refresh("select * from exam where examID='"+txt1.getText().trim()+"' ");
          }
        }else if(chk2.isSelected())
        {
           if(chk1.isSelected()&&!chk3.isSelected())
           {
            refresh("select * from exam where examID='"+txt1.getText().trim()+"'and stuID='"+txt2.getText().trim()+"'");
           }else if(chk3.isSelected()&&!chk1.isSelected())
           {
             refresh("select * from exam where stuID='"+txt2.getText().trim()+"'and courseID='"+txt3.getText().trim()+"'");
           }else if(!(chk1.isSelected()&&chk3.isSelected()))
           {
            refresh("select * from exam where stuID='"+txt2.getText().trim()+"'");
           }
        }else if(chk3.isSelected())
        {
          if(chk1.isSelected()&&!chk2.isSelected())
          {
          refresh("select * from exam where examID='"+txt1.getText().trim()+"'and courseID='"+txt3.getText().trim()+"'");
          }else if(chk2.isSelected()&&!chk1.isSelected())
          {
           refresh("select * from exam where stuID='"+txt2.getText().trim()+"'and courseID='"+txt3.getText().trim()+"'");
          }else if(!(chk1.isSelected()&&chk3.isSelected()))
          {
           refresh("select * from exam where courseID='"+txt3.getText().trim()+"'");
          }
        }else
        {
         refresh("select * from exam");
        }
        if(chk1.isSelected()&&chk2.isSelected()&&chk3.isSelected())
        {
         refresh("select * from exam where examID='"+txt1.getText().trim()+"'and stuID='"+txt2.getText().trim()+"'and courseID='"+txt3.getText().trim()+"'");
        }

    }
}


class Exam_but1_actionAdapter implements ActionListener {
    private Exam adaptee;
    Exam_but1_actionAdapter(Exam adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but1_actionPerformed(e);
    }
}


class Exam_but3_actionAdapter implements ActionListener {
    private Exam adaptee;
    Exam_but3_actionAdapter(Exam adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but3_actionPerformed(e);
    }
}


class Exam_but4_actionAdapter implements ActionListener {
    private Exam adaptee;
    Exam_but4_actionAdapter(Exam adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but4_actionPerformed(e);
    }
}


class Exam_but5_actionAdapter implements ActionListener {
    private Exam adaptee;
    Exam_but5_actionAdapter(Exam adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but5_actionPerformed(e);
    }
}


class Exam_but2_actionAdapter implements ActionListener {
    private Exam adaptee;
    Exam_but2_actionAdapter(Exam adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}
