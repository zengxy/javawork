package jdbc;
import java.sql.*;
import java.io.File;
import java.io.FileReader;
import java.io.BufferedReader;

import util.Logger;

import java.util.Date;
import java.text.SimpleDateFormat;

public class DbManager {
   private Connection con=null;
   private Statement stm=null;
   Logger log=new Logger();
   
   
   /**
    * @author gwh
    */
    public DbManager()
    {
       
            String url="jdbc:sqlserver://127.0.0.1:1433;databaseName=information;user=sa;password=123456";       
            try{
             Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            }catch (Exception ex) {
             System.out.println("����ʧ��1");
             log.log(ex.getMessage());
           }
             try{
               con=DriverManager.getConnection(url);
             }catch (Exception ex) {
             	System.out.println("����ʧ��2");
                log.log(ex.getMessage());
               }
             
             try {
             stm = con.createStatement();
             }  catch(Exception ex)
           {
        	System.out.println("����ʧ��3");
           log.log(ex.getMessage());
           }

    } 

    public int exec(String sql)
    {
       int n=0;
       System.out.println(sql);
    try {
        n = stm.executeUpdate(sql);
        System.out.println("�����ɹ�����Ӱ�������Ϊ"+n+"��");
    } catch (SQLException ex) {
      log.log(ex.getMessage());
    }
    return n;
    }

    public ResultSet query(String sql)
    {
       ResultSet rs=null;
       System.out.println(sql);
    try {
        rs = stm.executeQuery(sql);
    } catch (SQLException ex) {
     log.log(ex.getMessage());
    }
    return rs;
    }

}
