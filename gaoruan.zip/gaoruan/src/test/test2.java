package test;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class test2 {
	public static void main(String[] args) {

		JFrame mainFrame = new JFrame("��ҵ�ύ");
		JPanel mainJPanel = new JPanel();
	    
	    JLabel questionLabel = new JLabel("��������");
	    JTextArea questionArea = new JTextArea();
	   
	    JLabel courseLabel = new JLabel("�γ̱��");
	    JComboBox courseIDBox =new JComboBox();
	    
	    
	    JLabel blanklaJLabel = new JLabel(" ");
	    JButton commitButton = new JButton("�ύ");   
	    mainJPanel.setLayout(new GridLayout(3, 2));
	   
	    
	    questionArea.setTabSize(4);
	   // questionArea.setFont(new Font("�꿬��", Font.BOLD, 13));
	    questionArea.setLineWrap(true);// �����Զ����й���
	    questionArea.setWrapStyleWord(true);// ������в����ֹ���
	    questionArea.setBackground(Color.white);
	    
	    
	    
	    courseIDBox.addItem("1");
	    courseIDBox.addItem("2");


	    mainJPanel.add(questionLabel);
	    mainJPanel.add(questionArea);
	    
	    mainJPanel.add(courseLabel);
	    mainJPanel.add(courseIDBox);
	    
	    mainJPanel.add(blanklaJLabel);
	    commitButton.setSize(29, 39);
	    mainJPanel.add(commitButton);
	    
	    mainFrame.add(mainJPanel);
	    mainFrame.setSize(400, 300);
	    mainFrame.setLocation(400, 200);
	    mainFrame.setVisible(true);
	    mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	   // JOptionPane.showMessageDialog(null,"hh","121",JOptionPane.OK_OPTION);
	}
}
