package util;
import java.io.IOException;
import java.io.FileWriter;
import java.io.BufferedWriter;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.io.File;
import java.io.FileReader;
public class Logger
{
    BufferedWriter bw;
    public Logger()
    {
        try {

            Date d=new Date();
            SimpleDateFormat s=new SimpleDateFormat("20y��M��d��");
            String ss=String.valueOf(s.format(d));
            File f=new File("");   //����һ���ļ�����
            FileWriter fw = new FileWriter(f.getAbsolutePath()+"\\"+ss+".log");  //����һ���ļ�д�����
            bw = new BufferedWriter(fw);
        } catch (IOException ex)
        {
            System.out.println(ex.getMessage());
        }
    }

    public void log(String message)
    {
      Date d=new Date();
      SimpleDateFormat s=new SimpleDateFormat("20y��M��d�� hh:mm:ss");
    try {
        bw.newLine();
        bw.write(s.format(d) + ":  " + message);
        bw.flush();
    } catch (IOException ex)
    {
     System.out.println(ex.getMessage());
    }
    }
}
