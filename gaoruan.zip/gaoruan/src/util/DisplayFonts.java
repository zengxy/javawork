package util;

import java.awt.Font;
import javax.swing.plaf.FontUIResource;
import javax.swing.UIManager;
import java.util.Enumeration;

public class DisplayFonts {
    public DisplayFonts() {
    }

    public static void initGlobalFontSetting(String font, int size) {
              for (Enumeration keys = UIManager.getDefaults().keys(); keys.hasMoreElements();) {

                      Object key = keys.nextElement();
                      Object value = UIManager.get(key);

                      if (value instanceof FontUIResource) {
                              FontUIResource rs = (FontUIResource) value;
                              Font fontRes = new Font(font, rs.getStyle(), size);
                              UIManager.put(key, new FontUIResource(fontRes));

                      }
              }
      }

}
