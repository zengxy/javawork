package dao;
import jdbc.DbManager;
import javax.swing.table.*;
import java.util.Vector;
import java.sql.ResultSet;
import java.sql.*;
public class StudentDAO
{
    DbManager db=new DbManager();
    DefaultTableModel model=new DefaultTableModel();   //����һ��ģ��
    public StudentDAO()
    {
    }


    public DefaultTableModel refresh(String sql)
    {
       ResultSet rs=db.query(sql);
       Vector data=new Vector();
       Vector head=new Vector();
       head.add("���Ա��");
       head.add("ѧ�����");
       head.add("�γ̱��");
       head.add("���Գɼ�");
       head.add("���Գɼ�");
       try {
           while(rs.next())
           {
             Vector v=new Vector();
             v.add(rs.getString(1));
             v.add(rs.getString(2));
             v.add(rs.getString(3));
             v.add(rs.getString(4));
             v.add(rs.getString(5));
             data.add(v);
           }

       } catch (SQLException ex)
       {
        System.out.println(ex.getMessage());
       }
       model.setDataVector(data,head);        //�����ݣ���ͷ���ӵ�ģ����
       return model;
    }

    public ResultSet query(String sql)
    {
     ResultSet rs=db.query(sql);
     return rs;
    }

//    public boolean LoginCheck(String user,String pwd)
//    {
//       ResultSet rs=db.query("select * from userInfo where userName='"+user+"'and pwd='"+pwd+"'");
//    try {
//        if (rs.next()) {
//            return true;
//        }
//       } catch (SQLException ex)
//       {
//           System.out.println(ex.getMessage());
//       }
//        return false;
//    }
}
