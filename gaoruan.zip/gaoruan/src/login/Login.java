package login;
import java.awt.Color;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JPopupMenu;
import javax.swing.JRootPane;
import javax.swing.JTextField;

import jdbc.DbManager;
import studentframe.StudentFrame;
import teacherframe.TeacherFrame;
import util.Logger;
import adminframe.AdminFrame;
import adminframe.tools.ConfigureFrame;



public class Login extends JFrame {

	public Login() {
        try {
            jbInit();

        } catch (Exception exception) {
           //log.log(exception.getMessage());
        }
    }

    private void jbInit() throws Exception {
        getContentPane().setLayout(null);
        lab.setFont(new java.awt.Font("����", Font.BOLD, 25));
        lab.setBorder(null);
        lab.setIcon(img1);
        lab.setBounds(new Rectangle( -11, 0, 426, 71));
        jPanel1.setBackground(new Color(240, 255, 240));
        jPanel1.setBorder(BorderFactory.createEtchedBorder());
        jPanel1.setBounds(new Rectangle(45, 70, 267, 116));
        jPanel1.setLayout(null);
        lab1.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        lab1.setText("�û���");
        lab1.setBounds(new Rectangle(25, 25, 50, 30));
        lab2.setFont(new java.awt.Font("������", Font.PLAIN, 14));
        lab2.setText("��  ��");
        lab2.setBounds(new Rectangle(25, 67, 50, 30));
        txt1.setFont(new java.awt.Font("������", Font.PLAIN, 14));

        txt1.setBounds(new Rectangle(85, 30, 140, 25));
        txt1.addFocusListener(new Login_txt1_focusAdapter(this));
        txt2.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        txt2.setBounds(new Rectangle(85, 70, 140, 25));
        txt2.setEchoChar('*');
        txt2.addFocusListener(new Login_txt2_focusAdapter(this));
        txt2.addKeyListener(new Login_txt2_keyAdapter(this));
        but1.setBackground(new Color(240, 255, 240));
        but1.setBounds(new Rectangle(97, 209, 83, 28));
        but1.setFont(new java.awt.Font("����_GB2312", Font.PLAIN, 14));
        but1.setBorder(null);
        but1.setToolTipText("");
        but1.setIcon(img2);
        but1.addKeyListener(new Login_but1_keyAdapter(this));
        but1.addActionListener(new Login_but1_actionAdapter(this));
        but2.setBackground(new Color(240, 255, 240));
        but2.setBounds(new Rectangle(217, 208, 77, 29));
        but2.setFont(new java.awt.Font("����_GB2312", Font.PLAIN, 14));
        but2.setBorder(null);
        but2.setIcon(img3);
        but2.addActionListener(new Login_but2_actionAdapter(this));
        shuoming.setFont(new java.awt.Font("������", Font.PLAIN, 13));
        shuoming.setForeground(new Color(255, 0, 137));
        shuoming.setBounds(new Rectangle(100, 2, 148, 29));
        this.setUndecorated(true);//����ʾWindows������
        this.getRootPane().setWindowDecorationStyle(JRootPane.WARNING_DIALOG  );  //��ʾjava ������
        this.getContentPane().setBackground(new Color(240, 255, 240));
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setForeground(new Color(240, 255, 240));
        this.setTitle("�������ϵͳ");
        this.addMouseListener(new Login_this_mouseAdapter(this));


        jMenuItem1.setText("����");
        jMenuItem2.setText("����");
        jMenuItem3.setText("ճ��");
        hide.setBounds(new Rectangle(0, 0, 44, 25));
        hide.addMouseListener(new Login_hide_mouseAdapter(this));

        jPanel1.add(txt1);
        jPanel1.add(txt2);
        jPanel1.add(lab2);
        jPanel1.add(lab1);
        jPanel1.add(shuoming);
        this.getContentPane().add(lab);
        this.getContentPane().add(hide);
        this.getContentPane().add(but2);
        this.getContentPane().add(but1);
        this.getContentPane().add(jPanel1);
        jPopupMenu1.add(jMenuItem1);
        jPopupMenu1.add(jMenuItem2);
        jPopupMenu1.add(jMenuItem3);

    }

    JLabel lab = new JLabel();
    ImageIcon img1=new ImageIcon(this.getClass().getResource("/img/login.jpg"));
    JPanel jPanel1 = new JPanel();
    JLabel lab1 = new JLabel();
    JLabel lab2 = new JLabel();
    JTextField txt1 = new JTextField();
    JPasswordField txt2 = new JPasswordField();
    JButton but1 = new JButton();
    ImageIcon img2=new ImageIcon(this.getClass().getResource("/img/but1.jpg"));
    JButton but2 = new JButton();
    ImageIcon img3=new ImageIcon(this.getClass().getResource("/img/but2.jpg"));
    JLabel shuoming = new JLabel();



    public static void main(String[] args)
    {

        Login f=new Login();
        f.setSize(370,300);
        f.setLocation(300,200);
        f.setVisible(true);
        f.setResizable(false);
    }
    DbManager db=new DbManager();
    JPopupMenu jPopupMenu1 = new JPopupMenu();
    JMenuItem jMenuItem1 = new JMenuItem();
    JMenuItem jMenuItem2 = new JMenuItem();
    JMenuItem jMenuItem3 = new JMenuItem();
    JLabel hide = new JLabel();

    public void but1_actionPerformed(ActionEvent e) {
        String password=String.valueOf(txt2.getPassword());
      //��ѯ���ݿ�����û�д��û���������
     ResultSet rs=db.query("select * from userInfo where userName='"+txt1.getText().trim()+"'and pwd='"+password+"'");
    try {
        if (rs.next())
        {
            //�����������¼����������ȥ���մ�����¼��ĵ���������(��Ȩ��)  ����������ȥ����
           //Integer grade=Integer.valueOf(rs.getString(3));   //���ַ���ת�������ͣ�ͨ��valueOf()����
           int grade=Integer.parseInt(rs.getString(3));
           switch(grade)
         {
          case 1:
        	  	String studentID=txt1.getText();
                new StudentFrame(studentID);
                this.setVisible(false);
                break;
          case 2:
                new TeacherFrame(txt1.getText());   //ͨ��new ���ù��췽��AdminFrame() �����û�����Ϊʵ�δ���ȥ
                this.setVisible(false);
                break;
          case 3:
              new AdminFrame(txt1.getText());    //ͨ��new ���ù��췽��AdminFrame() �����û�����Ϊʵ�δ���ȥ
              this.setVisible(false);
              break;
         }

        }else
        {
            shuoming.setText("�û������������");
        }
    } catch (SQLException ex)
    {
        log.log(ex.getMessage());
    }
 }
   Logger log=new Logger();
    public void txt2_keyPressed(KeyEvent keyEvent)    //������м��̰��������¼�
    {
     if(keyEvent.getKeyCode()==10)        //���̵�ASCII��Ϊ10
     {
      but1_actionPerformed(null);
     }
    }

    public void but1_keyPressed(KeyEvent keyEvent)   //��ť�м��̰��������¼�
    {
        if(keyEvent.getKeyCode()==10)        //���̵�ASCII��Ϊ10
       {
        but1_actionPerformed(null);
       }

    }

    public void txt1_focusLost(FocusEvent e)   //�ı���txt1  ʧȥ�����¼�
    {
     if(txt1.getText().trim().equals(""))
     {
      shuoming.setText("�û�������Ϊ��");
     }else
     {
      shuoming.setText("");
     }
    }

    public void txt1_focusGained(FocusEvent e)  //�ı���txt1  �õ������¼�
    {
       shuoming.setText("");
    }

    public void txt2_focusLost(FocusEvent e)   //�ı���txt2  ʧȥ�����¼�
    {
        String password=String.valueOf(txt2.getPassword());
        if(password.equals(""))
        {
         shuoming.setText("���벻��Ϊ��");
        }
        else
        {
         shuoming.setText("");
        }

    }

    public void this_mouseClicked(MouseEvent e)   //������������¼�
    {
       if(e.getButton()==3)       //�ж�������Ƿ����Ҽ�(3���Ҽ�) e��ʱ�������
       {
           // this.getX()+e.getX()�����X����+����X����  this.getY()+e.getY()�����Y����+����Y����
        jPopupMenu1.setLocation(this.getX()+e.getX(),this.getY()+e.getY());
        jPopupMenu1.setVisible(true);  //��ݲ˵���ʾ����
       }else
       {
        jPopupMenu1.setVisible(false);
       }
    }

    public void hide_mouseClicked(MouseEvent e)
    {
        String ip=null;
        String user=null;
        String pwd=null;
        if(e.getButton()==3)
        {
            String s = JOptionPane.showInputDialog("");
            if (!s.equals("admin")) {
                JOptionPane.showMessageDialog(this, "���벻��ȷ");
            } else
            {
                try
                {
                    File f = new File("");
                    FileReader fr = new FileReader(f.getAbsolutePath() +"\\youzi.ini");
                    BufferedReader br = new BufferedReader(fr);
                     ip=br.readLine();
                     user=br.readLine();
                     pwd=br.readLine();
                     br.close();
                 } catch (FileNotFoundException ex)
               {
                log.log(ex.getMessage());
               }catch(Exception ex)
               {
               log.log(ex.getMessage());
               }

                ConfigureFrame c = new ConfigureFrame();
                c.setSize(350, 380);
                c.setLocation(200, 110);
                c.setVisible(true);
                c.setResizable(false);
                c.TianJia(ip,user,pwd);

            }

        }
    }

    public void but2_actionPerformed(ActionEvent e) {
       System.exit(0);
    }
}


class Login_hide_mouseAdapter extends MouseAdapter {
    private Login adaptee;
    Login_hide_mouseAdapter(Login adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.hide_mouseClicked(e);
    }
}


class Login_but2_actionAdapter implements ActionListener {
    private Login adaptee;
    Login_but2_actionAdapter(Login adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent e) {
        adaptee.but2_actionPerformed(e);
    }
}



class Login_this_mouseAdapter extends MouseAdapter {
    private Login adaptee;
    Login_this_mouseAdapter(Login adaptee) {
        this.adaptee = adaptee;
    }

    public void mouseClicked(MouseEvent e) {
        adaptee.this_mouseClicked(e);
    }
}


class Login_txt1_focusAdapter extends FocusAdapter {
    private Login adaptee;
    Login_txt1_focusAdapter(Login adaptee) {
        this.adaptee = adaptee;
    }

    public void focusLost(FocusEvent e) {
        adaptee.txt1_focusLost(e);
    }

    public void focusGained(FocusEvent e) {
        adaptee.txt1_focusGained(e);
    }
}


class Login_but1_actionAdapter implements ActionListener {
    private Login adaptee;
    private ActionEvent e;
    Login_but1_actionAdapter(Login adaptee) {
        this.adaptee = adaptee;
    }

    public void actionPerformed(ActionEvent actionEvent) {
        adaptee.but1_actionPerformed(e);
    }
}


class Login_but1_keyAdapter extends KeyAdapter {
    private Login adaptee;
    Login_but1_keyAdapter(Login adaptee) {
        this.adaptee = adaptee;
    }

    public void keyPressed(KeyEvent keyEvent) {
        adaptee.but1_keyPressed(keyEvent);
    }
}


class Login_txt2_keyAdapter extends KeyAdapter {
    private Login adaptee;
    Login_txt2_keyAdapter(Login adaptee) {
        this.adaptee = adaptee;
    }

    public void keyPressed(KeyEvent keyEvent) {
        adaptee.txt2_keyPressed(keyEvent);
    }
}


class Login_txt2_focusAdapter extends FocusAdapter {
    private Login adaptee;
    Login_txt2_focusAdapter(Login adaptee) {
        this.adaptee = adaptee;
    }

    public void focusLost(FocusEvent e) {
        adaptee.txt2_focusLost(e);
    }
}
